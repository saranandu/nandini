import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import request from 'supertest';
import bcrypt from 'bcryptjs';
import { createDatabase } from './db.js';
import { createApp } from './app.js';

let db;
let app;
let judgePassword = 'VeryStrongJudgePassword!';

async function setup({ registrationDeadline = null, judgingDeadline = null } = {}) {
  db = createDatabase(':memory:');
  const passwordHash = await bcrypt.hash(judgePassword, 4);
  db.prepare('INSERT INTO judges(id,name,title,email,password_hash,active) VALUES(?,?,?,?,?,1)')
    .run('judge-mehta', 'Dr. Mehta', 'Product & Innovation', 'judge@example.test', passwordHash);
  db.prepare('INSERT INTO teams(id,name,track,leader,email,created_at) VALUES(?,?,?,?,?,?)')
    .run('team-test', 'Test Team', 'Healthcare', 'Aarav Sharma', 'lead@example.test', new Date().toISOString());
  db.prepare('INSERT INTO members(id,team_id,name,email,role) VALUES(?,?,?,?,?)')
    .run('member-test', 'team-test', 'Aarav Sharma', 'lead@example.test', 'Team lead');
  db.prepare(`INSERT INTO projects(id,team_id,title,tagline,github,demo,video,stack_json,created_at)
    VALUES(?,?,?,?,?,?,?,?,?)`).run('project-test', 'team-test', 'Test Project', 'A safe test project tagline', 'https://github.com/example/project', '', '', '[]', new Date().toISOString());
  app = createApp({ db, config: {
    jwtSecret: 'this-is-a-test-secret-that-is-long-enough-123456',
    registrationDeadline,
    submissionDeadline: null,
    judgingDeadline,
  } });
}

afterEach(() => { if (db?.open) db.close(); });

describe('HackHarbor API security and validation', () => {
  beforeEach(async () => setup());

  it('blocks score writes when the request is not authenticated', async () => {
    const response = await request(app).post('/api/scores').send({
      projectId: 'project-test', innovation: 9, complexity: 9, uiux: 9, presentation: 9,
    });
    expect(response.status).toBe(401);
  });

  it('authenticates a judge and saves a score against that judge identity', async () => {
    const login = await request(app).post('/api/auth/judge').send({ email: 'judge@example.test', password: judgePassword });
    expect(login.status).toBe(200);
    const response = await request(app).post('/api/scores').set('Authorization', `Bearer ${login.body.token}`).send({
      projectId: 'project-test', innovation: 9, complexity: 8, uiux: 7, presentation: 10, note: 'Clear demo',
    });
    expect(response.status).toBe(200);
    expect(response.body.score.judgeId).toBe('judge-mehta');
    expect(response.body.scoreOutOf100).toBe(85);
  });

  it('rejects scores outside the 1–10 rubric', async () => {
    const login = await request(app).post('/api/auth/judge').send({ email: 'judge@example.test', password: judgePassword });
    const response = await request(app).post('/api/scores').set('Authorization', `Bearer ${login.body.token}`).send({
      projectId: 'project-test', innovation: 11, complexity: 8, uiux: 7, presentation: 10,
    });
    expect(response.status).toBe(400);
  });

  it('creates a team with private tokens and requires the token to submit projects', async () => {
    const teamResponse = await request(app).post('/api/teams').send({
      name: 'New Builders', track: 'EdTech', leader: 'Mira Nair', email: 'mira@example.test',
      members: [{ name: 'Mira Nair', email: 'mira@example.test', role: 'Team lead' }],
    });
    expect(teamResponse.status).toBe(201);
    expect(teamResponse.body.teamToken).toBeTruthy();
    const payload = {
      teamId: teamResponse.body.team.id, title: 'Learn With Me', tagline: 'Personalized lessons for everyone',
      github: 'https://github.com/example/learn', demo: '', video: '', stack: ['React'],
    };
    const denied = await request(app).post('/api/projects').send(payload);
    expect(denied.status).toBe(403);
    const accepted = await request(app).post('/api/projects').set('X-Team-Token', teamResponse.body.teamToken).send(payload);
    expect(accepted.status).toBe(201);
  });

  it('creates short-lived invite tokens and validates team roster size on join', async () => {
    const teamResponse = await request(app).post('/api/teams').send({
      name: 'Invite Team', track: 'Fintech', leader: 'Lead Person', email: 'lead2@example.test',
      members: [{ name: 'Lead Person', email: 'lead2@example.test', role: 'Team lead' }],
    });
    const joined = await request(app).post(`/api/teams/${teamResponse.body.team.id}/join`).send({
      name: 'New Teammate', email: 'new@example.test', token: teamResponse.body.inviteToken,
    });
    expect(joined.status).toBe(201);
    expect(joined.body.teamToken).toBeTruthy();
  });

  it('locks registrations after the configured deadline', async () => {
    db.close();
    await setup({ registrationDeadline: '2020-01-01T00:00:00Z' });
    const response = await request(app).post('/api/teams').send({
      name: 'Late Team', track: 'Fintech', leader: 'Lead Person', email: 'late@example.test',
      members: [{ name: 'Lead Person', email: 'late@example.test', role: 'Team lead' }],
    });
    expect(response.status).toBe(423);
    expect(response.body.error).toMatch(/deadline has passed/i);
  });
});
