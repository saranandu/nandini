import { z } from 'zod';

const safeName = z.string().trim().min(2).max(60);
const email = z.string().trim().email().max(254).transform((value) => value.toLowerCase());
const httpUrl = z.string().trim().url().refine((value) => ['http:', 'https:'].includes(new URL(value).protocol), 'Use an http or https URL');

export const teamSchema = z.object({
  name: z.string().trim().min(2).max(36),
  track: z.enum(['Fintech', 'EdTech', 'Healthcare', 'Web3', 'Open Innovation']),
  leader: safeName,
  email,
  members: z.array(z.object({ name: safeName, email, role: z.enum(['Team lead', 'Member']).optional() })).min(1).max(4),
}).superRefine((team, ctx) => {
  const normalized = team.members.map((member) => member.email);
  if (new Set(normalized).size !== normalized.length) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'A team cannot contain duplicate email addresses', path: ['members'] });
  }
  if (team.members[0]?.email !== team.email || team.members[0]?.name !== team.leader) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'The first roster member must be the team lead', path: ['members', 0] });
  }
});

export const joinTeamSchema = z.object({
  name: safeName,
  email,
  token: z.string().min(32).max(200),
});

export const projectSchema = z.object({
  teamId: z.string().min(1).max(80),
  title: z.string().trim().min(2).max(48),
  tagline: z.string().trim().min(5).max(100),
  github: httpUrl.refine((value) => {
    const url = new URL(value);
    return url.hostname.toLowerCase().replace(/^www\./, '') === 'github.com'
      && url.pathname.split('/').filter(Boolean).length === 2;
  }, 'A GitHub repository URL with owner and repository is required'),
  demo: z.union([z.literal(''), httpUrl]).optional().default(''),
  video: z.union([z.literal(''), httpUrl.refine((value) => {
    const host = new URL(value).hostname.toLowerCase().replace(/^www\./, '');
    return ['youtube.com', 'm.youtube.com', 'youtu.be'].includes(host);
  }, 'Use a YouTube or youtu.be video link')]).optional().default(''),
  stack: z.array(z.string().trim().min(1).max(32)).max(8).default([]),
});

export const scoreSchema = z.object({
  projectId: z.string().min(1).max(80),
  innovation: z.number().int().min(1).max(10),
  complexity: z.number().int().min(1).max(10),
  uiux: z.number().int().min(1).max(10),
  presentation: z.number().int().min(1).max(10),
  note: z.string().trim().max(1000).optional().default(''),
});

export const loginSchema = z.object({
  email,
  password: z.string().min(8).max(200),
});
