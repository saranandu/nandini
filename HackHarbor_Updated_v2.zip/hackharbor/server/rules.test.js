import { describe, expect, it } from 'vitest';
import { analyzeConsensus, assertBeforeDeadline, buildLeaderboard, isBeforeDeadline, scoreOutOf100 } from './rules.js';

describe('server-side score rules', () => {
  it('matches the four weighted dimensions', () => {
    expect(scoreOutOf100({ innovation: 9, complexity: 8, uiux: 7, presentation: 10 })).toBe(85);
  });

  it('rejects evaluations after their configured deadline', () => {
    const deadline = '2026-11-19T23:59:59+05:30';
    expect(isBeforeDeadline(deadline, new Date('2026-11-20T00:00:00+05:30'))).toBe(false);
    expect(() => assertBeforeDeadline(deadline, 'Judging', new Date('2026-11-20T00:00:00+05:30'))).toThrow(/deadline has passed/);
  });

  it('treats an unconfigured deadline as open', () => {
    expect(isBeforeDeadline(null)).toBe(true);
  });

  it('flags high disagreement for moderator review', () => {
    const metrics = analyzeConsensus([
      { innovation: 10, complexity: 10, uiux: 10, presentation: 10 },
      { innovation: 3, complexity: 3, uiux: 3, presentation: 3 },
    ]);
    expect(metrics.key).toBe('review');
    expect(metrics.spread).toBeGreaterThan(20);
  });

  it('aggregates and ranks team scores', () => {
    const ranking = buildLeaderboard({
      teams: [{ id: 'a', name: 'Alpha', track: 'Fintech' }, { id: 'b', name: 'Beta', track: 'Web3' }],
      projects: [{ id: 'pa', teamId: 'a' }, { id: 'pb', teamId: 'b' }],
      scores: [{ projectId: 'pa', innovation: 9, complexity: 9, uiux: 9, presentation: 9 }, { projectId: 'pb', innovation: 10, complexity: 10, uiux: 10, presentation: 10 }],
    });
    expect(ranking.map((team) => team.name)).toEqual(['Beta', 'Alpha']);
  });
});
