import { describe, expect, it } from 'vitest';
import { projectSchema, scoreSchema, teamSchema } from './validation.js';

const validTeam = {
  name: 'Quantum Coders', track: 'Healthcare', leader: 'Aarav Sharma', email: 'aarav@example.test',
  members: [{ name: 'Aarav Sharma', email: 'aarav@example.test', role: 'Team lead' }],
};

describe('request validation', () => {
  it('accepts a correctly structured team roster', () => {
    expect(teamSchema.safeParse(validTeam).success).toBe(true);
  });

  it('rejects teams with more than four members or duplicate addresses', () => {
    const tooMany = { ...validTeam, members: Array.from({ length: 5 }, (_, index) => ({ name: `Member ${index}`, email: `m${index}@example.test` })) };
    const duplicate = { ...validTeam, members: [...validTeam.members, { name: 'Second', email: 'aarav@example.test' }] };
    expect(teamSchema.safeParse(tooMany).success).toBe(false);
    expect(teamSchema.safeParse(duplicate).success).toBe(false);
  });

  it('accepts only a GitHub repository URL and YouTube video URL', () => {
    const project = {
      teamId: 'team-1', title: 'CardioScan', tagline: 'An accessible community health demo',
      github: 'https://github.com/example/cardioscan', demo: 'https://example.com/demo',
      video: 'https://youtu.be/abc123', stack: ['React'],
    };
    expect(projectSchema.safeParse(project).success).toBe(true);
    expect(projectSchema.safeParse({ ...project, github: 'https://github.com/' }).success).toBe(false);
    expect(projectSchema.safeParse({ ...project, video: 'https://example.com/video' }).success).toBe(false);
  });

  it('requires integer rubric scores between one and ten', () => {
    const validScore = { projectId: 'project-1', innovation: 9, complexity: 8, uiux: 7, presentation: 10 };
    expect(scoreSchema.safeParse(validScore).success).toBe(true);
    expect(scoreSchema.safeParse({ ...validScore, presentation: 10.5 }).success).toBe(false);
    expect(scoreSchema.safeParse({ ...validScore, innovation: 0 }).success).toBe(false);
  });
});
