export const RUBRIC_WEIGHTS = Object.freeze({
  innovation: 0.3,
  complexity: 0.3,
  uiux: 0.2,
  presentation: 0.2,
});

export function scoreOutOf100(score) {
  if (!score) return 0;
  return Object.entries(RUBRIC_WEIGHTS).reduce((total, [key, weight]) => {
    return total + Number(score[key] || 0) * weight * 10;
  }, 0);
}

export function isBeforeDeadline(deadline, now = new Date()) {
  if (!deadline) return true;
  const timestamp = Date.parse(deadline);
  if (!Number.isFinite(timestamp)) throw new Error(`Invalid deadline: ${deadline}`);
  return now.getTime() <= timestamp;
}

export function assertBeforeDeadline(deadline, label, now = new Date()) {
  if (!isBeforeDeadline(deadline, now)) {
    const error = new Error(`${label} deadline has passed. This action is locked.`);
    error.status = 423;
    throw error;
  }
}

export function analyzeConsensus(scores = []) {
  const values = scores.map(scoreOutOf100).sort((a, b) => a - b);
  if (values.length < 2) return { key: 'pending', label: values.length ? 'Needs another judge' : 'Not scored', spread: null, outlierCount: 0 };
  const mean = values.reduce((sum, value) => sum + value, 0) / values.length;
  const variance = values.reduce((sum, value) => sum + ((value - mean) ** 2), 0) / values.length;
  const spread = Math.sqrt(variance);
  const middle = Math.floor(values.length / 2);
  const median = values.length % 2 ? values[middle] : (values[middle - 1] + values[middle]) / 2;
  const outlierCount = values.length >= 3 ? values.filter((value) => Math.abs(value - median) > 15).length : 0;
  const key = spread < 5 ? 'strong' : spread < 12 ? 'mixed' : 'review';
  const label = key === 'strong' ? 'Strong agreement' : key === 'mixed' ? 'Mixed scores' : 'Review suggested';
  return { key, label, spread: Number(spread.toFixed(1)), outlierCount };
}

export function buildLeaderboard({ teams, projects, scores }, track = 'All tracks') {
  return teams
    .filter((team) => track === 'All tracks' || team.track === track)
    .map((team) => {
      const teamProjects = projects.filter((project) => project.teamId === team.id);
      const teamScores = scores.filter((score) => teamProjects.some((project) => project.id === score.projectId));
      const average = teamScores.length
        ? teamScores.reduce((sum, score) => sum + scoreOutOf100(score), 0) / teamScores.length
        : 0;
      return {
        ...team,
        project: teamProjects[0] || null,
        score: average,
        scoreCount: teamScores.length,
        scored: teamScores.length > 0,
        consensus: analyzeConsensus(teamScores),
      };
    })
    .sort((a, b) => {
      if (a.scored !== b.scored) return a.scored ? -1 : 1;
      if (b.score !== a.score) return b.score - a.score;
      return a.name.localeCompare(b.name);
    });
}
