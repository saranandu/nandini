import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import { mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { randomUUID } from 'node:crypto';
import { createSeedData } from '../src/data/seed.js';
import { JUDGES } from '../src/data/eventConfig.js';

export function createDatabase(filename = './server/data/hackharbor.sqlite') {
  const absolute = filename === ':memory:' ? filename : resolve(filename);
  if (absolute !== ':memory:') mkdirSync(dirname(absolute), { recursive: true });
  const db = new Database(absolute);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  db.exec(`
    CREATE TABLE IF NOT EXISTS teams (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL COLLATE NOCASE UNIQUE,
      track TEXT NOT NULL,
      leader TEXT NOT NULL,
      email TEXT NOT NULL COLLATE NOCASE,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS members (
      id TEXT PRIMARY KEY,
      team_id TEXT NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      email TEXT NOT NULL COLLATE NOCASE UNIQUE,
      role TEXT NOT NULL CHECK(role IN ('Team lead','Member'))
    );
    CREATE TABLE IF NOT EXISTS projects (
      id TEXT PRIMARY KEY,
      team_id TEXT NOT NULL UNIQUE REFERENCES teams(id) ON DELETE CASCADE,
      title TEXT NOT NULL,
      tagline TEXT NOT NULL,
      github TEXT NOT NULL,
      demo TEXT NOT NULL DEFAULT '',
      video TEXT NOT NULL DEFAULT '',
      stack_json TEXT NOT NULL DEFAULT '[]',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS judges (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      title TEXT NOT NULL,
      email TEXT UNIQUE COLLATE NOCASE,
      password_hash TEXT,
      active INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS scores (
      id TEXT PRIMARY KEY,
      project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
      judge_id TEXT NOT NULL REFERENCES judges(id),
      innovation INTEGER NOT NULL CHECK(innovation BETWEEN 1 AND 10),
      complexity INTEGER NOT NULL CHECK(complexity BETWEEN 1 AND 10),
      uiux INTEGER NOT NULL CHECK(uiux BETWEEN 1 AND 10),
      presentation INTEGER NOT NULL CHECK(presentation BETWEEN 1 AND 10),
      note TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL,
      UNIQUE(project_id, judge_id)
    );
    CREATE TABLE IF NOT EXISTS invite_tokens (
      token_hash TEXT PRIMARY KEY,
      team_id TEXT NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
      expires_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS team_access_tokens (
      token_hash TEXT PRIMARY KEY,
      team_id TEXT NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
      created_at TEXT NOT NULL,
      expires_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_members_team ON members(team_id);
    CREATE INDEX IF NOT EXISTS idx_projects_team ON projects(team_id);
    CREATE INDEX IF NOT EXISTS idx_scores_project ON scores(project_id);
  `);
  return db;
}

export async function seedDatabase(db, { judgeAccounts }) {
  const transaction = db.transaction(() => {
    for (const judge of JUDGES) {
      db.prepare(`INSERT OR IGNORE INTO judges(id,name,title,active) VALUES(?,?,?,0)`)
        .run(judge.id, judge.name, judge.title);
    }
    const { teams, projects, scores } = createSeedData();
    const insertTeam = db.prepare('INSERT OR IGNORE INTO teams(id,name,track,leader,email,created_at) VALUES(?,?,?,?,?,?)');
    const insertMember = db.prepare('INSERT OR IGNORE INTO members(id,team_id,name,email,role) VALUES(?,?,?,?,?)');
    const insertProject = db.prepare('INSERT OR IGNORE INTO projects(id,team_id,title,tagline,github,demo,video,stack_json,created_at) VALUES(?,?,?,?,?,?,?,?,?)');
    const insertScore = db.prepare('INSERT OR IGNORE INTO scores(id,project_id,judge_id,innovation,complexity,uiux,presentation,note,updated_at) VALUES(?,?,?,?,?,?,?,?,?)');
    for (const team of teams) {
      insertTeam.run(team.id, team.name, team.track, team.leader, team.email.toLowerCase(), team.createdAt);
      for (const member of team.members) insertMember.run(randomUUID(), team.id, member.name, member.email.toLowerCase(), member.role);
    }
    for (const project of projects) insertProject.run(project.id, project.teamId, project.title, project.tagline, project.github, project.demo || '', project.video || '', JSON.stringify(project.stack || []), project.createdAt);
    for (const score of scores) insertScore.run(score.id, score.projectId, score.judgeId, score.innovation, score.complexity, score.uiux, score.presentation, score.note || '', score.updatedAt || new Date().toISOString());
  });
  transaction();
  db.prepare('UPDATE judges SET active=0,email=NULL,password_hash=NULL').run();
  const saveJudge = db.prepare(`INSERT INTO judges(id,name,title,email,password_hash,active)
    VALUES(?,?,?,?,?,1)
    ON CONFLICT(id) DO UPDATE SET name=excluded.name,title=excluded.title,email=excluded.email,
      password_hash=excluded.password_hash,active=1`);
  for (const account of judgeAccounts) {
    const passwordHash = await bcrypt.hash(account.password, 12);
    saveJudge.run(account.id, account.name, account.title, account.email.toLowerCase(), passwordHash);
  }
}

export function readPublicData(db, includeJudgeNotesFor = null) {
  // Public bootstrap reveals roster size, not participant names or email addresses.
  const teams = db.prepare(`SELECT t.id,t.name,t.track,t.created_at AS createdAt,
      (SELECT COUNT(*) FROM members m WHERE m.team_id=t.id) AS memberCount
      FROM teams t ORDER BY t.created_at`).all();
  const projects = db.prepare(`SELECT id,team_id AS teamId,title,tagline,github,demo,video,stack_json AS stackJson,created_at AS createdAt FROM projects ORDER BY created_at`).all()
    .map((project) => ({ ...project, stack: JSON.parse(project.stackJson), stackJson: undefined }));
  const scores = db.prepare(`SELECT id,project_id AS projectId,judge_id AS judgeId,innovation,complexity,uiux,presentation,
      CASE WHEN judge_id = ? THEN note ELSE '' END AS note,updated_at AS updatedAt FROM scores`).all(includeJudgeNotesFor || '');
  return {
    teams,
    projects,
    scores,
  };
}
