import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { createHash, randomBytes, randomUUID } from 'node:crypto';
import { ZodError } from 'zod';
import { isBeforeDeadline, assertBeforeDeadline, scoreOutOf100, buildLeaderboard } from './rules.js';
import { teamSchema, joinTeamSchema, projectSchema, scoreSchema, loginSchema } from './validation.js';
import { readPublicData } from './db.js';

const hashToken = (value) => createHash('sha256').update(value).digest('hex');
const nowIso = () => new Date().toISOString();
const parseBody = (schema, body) => schema.parse(body);

export function createApp({ db, config }) {
  if (!db) throw new Error('createApp requires a database connection');
  if (!config?.jwtSecret || config.jwtSecret.length < 32) throw new Error('JWT_SECRET must contain at least 32 characters');

  const app = express();
  app.disable('x-powered-by');
  app.use(helmet({
    contentSecurityPolicy: { directives: {
      defaultSrc: ["'self'"], scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      fontSrc: ["'self'", 'https://fonts.gstatic.com', 'data:'],
      imgSrc: ["'self'", 'data:', 'https:'], connectSrc: ["'self'"],
      objectSrc: ["'none'"], frameAncestors: ["'none'"],
    } },
  }));
  app.use(cors({ origin: config.corsOrigin || false }));
  app.use(express.json({ limit: '100kb' }));
  app.use((req, res, next) => { req.requestId = randomUUID(); res.setHeader('X-Request-Id', req.requestId); next(); });
  app.use('/api', rateLimit({ windowMs: 10 * 60 * 1000, limit: 180, standardHeaders: 'draft-7', legacyHeaders: false }));

  const deadlines = {
    registration: config.registrationDeadline,
    submission: config.submissionDeadline,
    judging: config.judgingDeadline,
  };

  function authenticate(req, res, next) {
    const header = req.get('authorization') || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : '';
    if (!token) return res.status(401).json({ error: 'Sign in as a judge to continue.' });
    try {
      const payload = jwt.verify(token, config.jwtSecret, { issuer: 'hackharbor', audience: 'hackharbor-judge' });
      if (payload.role !== 'judge') return res.status(403).json({ error: 'Judge role required.' });
      const judge = db.prepare('SELECT id,name,title,email,active FROM judges WHERE id=? AND active=1').get(payload.sub);
      if (!judge) return res.status(401).json({ error: 'Judge account is no longer active.' });
      req.judge = judge;
      next();
    } catch {
      return res.status(401).json({ error: 'Your judge session is invalid or has expired. Please sign in again.' });
    }
  }

  app.get('/api/health', (_req, res) => res.json({ status: 'ok', service: 'hackharbor-api', time: nowIso() }));

  app.get('/api/bootstrap', (req, res) => {
    const ownJudgeId = req.get('authorization')?.startsWith('Bearer ')
      ? (() => { try { return jwt.verify(req.get('authorization').slice(7), config.jwtSecret, { issuer: 'hackharbor', audience: 'hackharbor-judge' }).sub; } catch { return null; } })()
      : null;
    const data = readPublicData(db, ownJudgeId);
    const leaderboard = buildLeaderboard(data);
    res.json({ data, leaderboard, deadlines, serverTime: nowIso() });
  });

  app.post('/api/auth/judge', rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: 'draft-7', legacyHeaders: false }), async (req, res, next) => {
    try {
      const { email, password } = parseBody(loginSchema, req.body);
      const judge = db.prepare('SELECT id,name,title,email,password_hash AS passwordHash,active FROM judges WHERE email=? COLLATE NOCASE').get(email);
      const valid = judge?.active && judge.passwordHash && await bcrypt.compare(password, judge.passwordHash);
      if (!valid) return res.status(401).json({ error: 'Email or password is incorrect.' });
      const token = jwt.sign({ role: 'judge' }, config.jwtSecret, {
        subject: judge.id, expiresIn: '4h', issuer: 'hackharbor', audience: 'hackharbor-judge',
      });
      res.json({ token, judge: { id: judge.id, name: judge.name, title: judge.title, email: judge.email } });
    } catch (error) { next(error); }
  });

  app.get('/api/auth/me', authenticate, (req, res) => {
    res.json({ judge: { id: req.judge.id, name: req.judge.name, title: req.judge.title, email: req.judge.email } });
  });

  app.post('/api/teams', (req, res, next) => {
    try {
      assertBeforeDeadline(deadlines.registration, 'Team registration');
      const input = parseBody(teamSchema, req.body);
      const duplicateName = db.prepare('SELECT 1 FROM teams WHERE name=? COLLATE NOCASE').get(input.name);
      if (duplicateName) return res.status(409).json({ error: 'That team name is already registered.' });
      const emails = input.members.map((member) => member.email);
      const placeholders = emails.map(() => '?').join(',');
      const duplicateEmail = db.prepare(`SELECT 1 FROM members WHERE email IN (${placeholders}) LIMIT 1`).get(...emails);
      if (duplicateEmail) return res.status(409).json({ error: 'One or more member email addresses are already registered.' });

      const id = `team-${randomUUID()}`;
      const createdAt = nowIso();
      const inviteToken = randomBytes(32).toString('base64url');
      const teamToken = randomBytes(32).toString('base64url');
      const insert = db.transaction(() => {
        db.prepare('INSERT INTO teams(id,name,track,leader,email,created_at) VALUES(?,?,?,?,?,?)')
          .run(id, input.name, input.track, input.leader, input.email, createdAt);
        const memberStmt = db.prepare('INSERT INTO members(id,team_id,name,email,role) VALUES(?,?,?,?,?)');
        input.members.forEach((member, index) => memberStmt.run(randomUUID(), id, member.name, member.email, index === 0 ? 'Team lead' : 'Member'));
        const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();
        db.prepare('INSERT INTO invite_tokens(token_hash,team_id,expires_at) VALUES(?,?,?)')
          .run(hashToken(inviteToken), id, expiresAt);
        db.prepare('INSERT INTO team_access_tokens(token_hash,team_id,created_at,expires_at) VALUES(?,?,?,?)')
          .run(hashToken(teamToken), id, createdAt, expiresAt);
      });
      insert();
      const team = db.prepare('SELECT id,name,track,leader,created_at AS createdAt FROM teams WHERE id=?').get(id);
      team.memberCount = input.members.length;
      res.status(201).json({ team, inviteToken, teamToken });
    } catch (error) { next(error); }
  });

  app.post('/api/teams/:teamId/join', (req, res, next) => {
    try {
      assertBeforeDeadline(deadlines.registration, 'Team registration');
      const input = parseBody(joinTeamSchema, req.body);
      const join = db.transaction(() => {
        const team = db.prepare('SELECT id,name,track,created_at AS createdAt FROM teams WHERE id=?').get(req.params.teamId);
        if (!team) { const error = new Error('This team invite could not be found.'); error.status = 404; throw error; }
        const invite = db.prepare('SELECT token_hash FROM invite_tokens WHERE team_id=? AND token_hash=? AND expires_at>?')
          .get(team.id, hashToken(input.token), nowIso());
        if (!invite) { const error = new Error('This invite link is invalid or has expired.'); error.status = 403; throw error; }
        const count = db.prepare('SELECT COUNT(*) AS count FROM members WHERE team_id=?').get(team.id).count;
        if (count >= 4) { const error = new Error('This team roster is already full.'); error.status = 409; throw error; }
        if (db.prepare('SELECT 1 FROM members WHERE email=? COLLATE NOCASE').get(input.email)) {
          const error = new Error('This email address is already registered.'); error.status = 409; throw error;
        }
        db.prepare('INSERT INTO members(id,team_id,name,email,role) VALUES(?,?,?,?,?)')
          .run(randomUUID(), team.id, input.name, input.email, 'Member');
        const teamToken = randomBytes(32).toString('base64url');
        db.prepare('INSERT INTO team_access_tokens(token_hash,team_id,created_at,expires_at) VALUES(?,?,?,?)')
          .run(hashToken(teamToken), team.id, nowIso(), new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString());
        team.memberCount = count + 1;
        return { team, teamToken };
      });
      const result = join.immediate();
      res.status(201).json(result);
    } catch (error) { next(error); }
  });

  app.post('/api/projects', (req, res, next) => {
    try {
      assertBeforeDeadline(deadlines.submission, 'Project submission');
      const input = parseBody(projectSchema, req.body);
      if (!db.prepare('SELECT 1 FROM teams WHERE id=?').get(input.teamId)) return res.status(404).json({ error: 'Choose a registered team.' });
      const teamToken = req.get('x-team-token') || '';
      const access = teamToken ? db.prepare('SELECT 1 FROM team_access_tokens WHERE team_id=? AND token_hash=? AND expires_at>?').get(input.teamId, hashToken(teamToken), nowIso()) : null;
      if (!access) return res.status(403).json({ error: 'Team access is required. Register or join this team using its invitation link first.' });
      const existing = db.prepare('SELECT id,created_at AS createdAt FROM projects WHERE team_id=?').get(input.teamId);
      const id = existing?.id || `project-${randomUUID()}`;
      const createdAt = existing?.createdAt || nowIso();
      db.prepare(`INSERT INTO projects(id,team_id,title,tagline,github,demo,video,stack_json,created_at)
        VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(team_id) DO UPDATE SET title=excluded.title,tagline=excluded.tagline,
        github=excluded.github,demo=excluded.demo,video=excluded.video,stack_json=excluded.stack_json`)
        .run(id, input.teamId, input.title, input.tagline, input.github, input.demo, input.video, JSON.stringify(input.stack), createdAt);
      res.status(existing ? 200 : 201).json({ project: { id, ...input, createdAt } });
    } catch (error) { next(error); }
  });

  app.post('/api/scores', authenticate, (req, res, next) => {
    try {
      assertBeforeDeadline(deadlines.judging, 'Judging');
      const input = parseBody(scoreSchema, req.body);
      if (!db.prepare('SELECT 1 FROM projects WHERE id=?').get(input.projectId)) return res.status(404).json({ error: 'The selected project no longer exists.' });
      const id = `score-${randomUUID()}`;
      const updatedAt = nowIso();
      db.prepare(`INSERT INTO scores(id,project_id,judge_id,innovation,complexity,uiux,presentation,note,updated_at)
        VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(project_id,judge_id) DO UPDATE SET innovation=excluded.innovation,
        complexity=excluded.complexity,uiux=excluded.uiux,presentation=excluded.presentation,note=excluded.note,updated_at=excluded.updated_at`)
        .run(id, input.projectId, req.judge.id, input.innovation, input.complexity, input.uiux, input.presentation, input.note, updatedAt);
      const saved = db.prepare(`SELECT id,project_id AS projectId,judge_id AS judgeId,innovation,complexity,uiux,presentation,note,updated_at AS updatedAt
        FROM scores WHERE project_id=? AND judge_id=?`).get(input.projectId, req.judge.id);
      res.status(200).json({ score: saved, scoreOutOf100: scoreOutOf100(saved) });
    } catch (error) { next(error); }
  });

  app.get('/api/leaderboard', (_req, res) => {
    const data = readPublicData(db);
    res.json({ leaderboard: buildLeaderboard(data) });
  });

  app.use('/api', (_req, res) => res.status(404).json({ error: 'API route not found.' }));
  app.use((error, req, res, _next) => {
    if (error instanceof ZodError) {
      return res.status(400).json({ error: 'Please check the submitted details.', details: error.issues.map((issue) => ({ field: issue.path.join('.'), message: issue.message })) });
    }
    const status = Number.isInteger(error.status) ? error.status : (String(error.code || '').startsWith('SQLITE_CONSTRAINT') ? 409 : 500);
    if (status >= 500) console.error(`[${req.requestId}]`, error);
    const publicMessage = status >= 500 ? 'Something went wrong on the server. Please try again.' : (status === 409 && !error.status ? 'A conflicting team or member record already exists.' : error.message);
    return res.status(status).json({ error: publicMessage, requestId: req.requestId });
  });

  return app;
}
