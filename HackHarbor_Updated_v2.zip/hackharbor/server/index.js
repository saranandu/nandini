import 'dotenv/config';
import express from 'express';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createDatabase, seedDatabase } from './db.js';
import { createApp } from './app.js';

const required = ['JWT_SECRET'];
for (const key of required) {
  if (!process.env[key] || process.env[key].startsWith('CHANGE_ME')) {
    throw new Error(`Set ${key} in your .env file before starting HackHarbor. Copy .env.example to .env first.`);
  }
}
if (process.env.JWT_SECRET.length < 32) throw new Error('JWT_SECRET must be at least 32 characters long.');

let judgeAccounts;
if (process.env.JUDGE_ACCOUNTS_JSON?.trim()) {
  try { judgeAccounts = JSON.parse(process.env.JUDGE_ACCOUNTS_JSON); }
  catch { throw new Error('JUDGE_ACCOUNTS_JSON must be a valid JSON array.'); }
} else {
  if (!process.env.JUDGE_EMAIL || !process.env.JUDGE_PASSWORD || process.env.JUDGE_PASSWORD.startsWith('CHANGE_ME')) {
    throw new Error('Set JUDGE_EMAIL and JUDGE_PASSWORD in .env, or provide JUDGE_ACCOUNTS_JSON.');
  }
  judgeAccounts = [{
    id: 'judge-mehta', name: process.env.JUDGE_NAME || 'Dr. Mehta', title: 'Product & Innovation',
    email: process.env.JUDGE_EMAIL, password: process.env.JUDGE_PASSWORD,
  }];
}
if (!Array.isArray(judgeAccounts) || judgeAccounts.length === 0) throw new Error('At least one judge account is required.');
const ids = new Set();
const emails = new Set();
for (const account of judgeAccounts) {
  if (!account || typeof account.id !== 'string' || !/^judge-[a-z0-9-]{2,50}$/.test(account.id)
    || typeof account.name !== 'string' || account.name.trim().length < 2
    || typeof account.title !== 'string' || account.title.trim().length < 2
    || typeof account.email !== 'string' || !/^\S+@\S+\.\S+$/.test(account.email)
    || typeof account.password !== 'string' || account.password.length < 12) {
    throw new Error('Each judge account needs id (judge-*), name, title, valid email and a password of at least 12 characters.');
  }
  if (ids.has(account.id) || emails.has(account.email.toLowerCase())) throw new Error('Judge account IDs and emails must be unique.');
  ids.add(account.id); emails.add(account.email.toLowerCase());
}

const database = createDatabase(process.env.DATABASE_PATH || './server/data/hackharbor.sqlite');
await seedDatabase(database, { judgeAccounts });

const app = createApp({
  db: database,
  config: {
    jwtSecret: process.env.JWT_SECRET,
    registrationDeadline: process.env.REGISTRATION_DEADLINE || null,
    submissionDeadline: process.env.SUBMISSION_DEADLINE || null,
    judgingDeadline: process.env.JUDGING_DEADLINE || null,
    corsOrigin: process.env.CORS_ORIGIN || false,
  },
});

const currentDir = fileURLToPath(new URL('.', import.meta.url));
const distPath = resolve(currentDir, '../dist');
app.use(express.static(distPath));
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/')) return next();
  res.sendFile(resolve(distPath, 'index.html'), (error) => { if (error) next(); });
});

const port = Number(process.env.PORT || 4000);
app.listen(port, () => {
  console.log(`HackHarbor API listening on http://localhost:${port}`);
  console.log(`Active judge accounts: ${judgeAccounts.map((account) => account.email).join(', ')}`);
});

process.on('SIGINT', () => { database.close(); process.exit(0); });
process.on('SIGTERM', () => { database.close(); process.exit(0); });
