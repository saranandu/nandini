const TOKEN_KEY = 'hackharbor-judge-session';
const TEAM_TOKEN_KEY = 'hackharbor-team-sessions';

export function getJudgeToken() {
  try { return sessionStorage.getItem(TOKEN_KEY) || ''; }
  catch { return ''; }
}

export function setJudgeToken(token) {
  try { sessionStorage.setItem(TOKEN_KEY, token); }
  catch { /* Session storage may be disabled; authenticated actions will report the issue. */ }
}

export function clearJudgeToken() {
  try { sessionStorage.removeItem(TOKEN_KEY); }
  catch { /* Ignore browser storage failures during sign-out. */ }
}

export function getTeamTokens() {
  try { return JSON.parse(sessionStorage.getItem(TEAM_TOKEN_KEY) || '{}'); }
  catch { return {}; }
}

export function setTeamToken(teamId, token) {
  try { const tokens = getTeamTokens(); tokens[teamId] = token; sessionStorage.setItem(TEAM_TOKEN_KEY, JSON.stringify(tokens)); }
  catch { /* Team actions will display an access error if storage is unavailable. */ }
}

export function getTeamToken(teamId) { return getTeamTokens()[teamId] || ''; }

export async function apiRequest(path, { method = 'GET', body, token = getJudgeToken(), teamToken = '' } = {}) {
  let response;
  try {
    response = await fetch(path, {
      method,
      headers: {
        Accept: 'application/json',
        ...(body === undefined ? {} : { 'Content-Type': 'application/json' }),
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        ...(teamToken ? { 'X-Team-Token': teamToken } : {}),
      },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    });
  } catch {
    throw new Error('Cannot reach the HackHarbor server. Start the API with `npm run dev` and try again.');
  }

  let payload = {};
  try { payload = await response.json(); }
  catch { /* A non-JSON error response is handled below. */ }

  if (!response.ok) {
    const detail = payload.details?.[0]?.message;
    const error = new Error(detail || payload.error || `Request failed (${response.status}).`);
    error.status = response.status;
    error.requestId = payload.requestId || '';
    throw error;
  }
  return payload;
}
