import { describe, expect, it } from 'vitest';
import { analyzeConsensus, getLeaderboard, scoreOutOf100 } from './scoring.js';

describe('weighted judging formula', () => {
  it('returns 100 for a perfect rubric', () => {
    expect(scoreOutOf100({ innovation: 10, complexity: 10, uiux: 10, presentation: 10 })).toBe(100);
  });

  it('applies weights of 30/30/20/20', () => {
    expect(scoreOutOf100({ innovation: 9, complexity: 8, uiux: 7, presentation: 10 })).toBe(85);
  });

  it('returns zero for a missing evaluation', () => {
    expect(scoreOutOf100(null)).toBe(0);
  });

  it('flags material judge disagreement without changing the mean score', () => {
    const result = analyzeConsensus([
      { innovation: 10, complexity: 10, uiux: 10, presentation: 10 },
      { innovation: 4, complexity: 4, uiux: 4, presentation: 4 },
    ]);
    expect(result.key).toBe('review');
    expect(result.outlierCount).toBe(0);
  });
});

describe('leaderboard aggregation', () => {
  const sample = {
    teams: [
      { id: 't1', name: 'Alpha', track: 'Fintech' },
      { id: 't2', name: 'Beta', track: 'Healthcare' },
      { id: 't3', name: 'Gamma', track: 'Fintech' },
    ],
    projects: [
      { id: 'p1', teamId: 't1', title: 'One' },
      { id: 'p2', teamId: 't2', title: 'Two' },
    ],
    scores: [
      { projectId: 'p1', judgeId: 'j1', innovation: 9, complexity: 9, uiux: 9, presentation: 9 },
      { projectId: 'p1', judgeId: 'j2', innovation: 7, complexity: 7, uiux: 7, presentation: 7 },
      { projectId: 'p2', judgeId: 'j1', innovation: 10, complexity: 10, uiux: 10, presentation: 10 },
    ],
  };

  it('averages judge scores and sorts highest first', () => {
    const rows = getLeaderboard(sample);
    expect(rows[0].name).toBe('Beta');
    expect(rows[0].score).toBe(100);
    expect(rows[1].score).toBe(80);
    expect(rows[2].scored).toBe(false);
  });

  it('filters by track without changing the scoring formula', () => {
    expect(getLeaderboard(sample, 'Fintech').map((row) => row.name)).toEqual(['Alpha', 'Gamma']);
  });
});
