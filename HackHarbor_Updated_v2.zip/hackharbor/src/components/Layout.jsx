import { NavLink, Link, Outlet } from 'react-router-dom';
import { useHackathon } from '../context/HackathonContext';

const links = [
  { to: '/', label: 'Discover', end: true },
  { to: '/register', label: 'Register' },
  { to: '/submit', label: 'Submit idea' },
  { to: '/leaderboard', label: 'Leaderboard' },
  { to: '/judge', label: 'Judges' },
];

export default function Layout() {
  const { theme, toggleTheme, isJudge, logoutJudge, apiStatus, apiError } = useHackathon();
  return (
    <div className="site-shell">
      <header className="topbar">
        <Link to="/" className="brand" aria-label="HackHarbor home">
          <span className="brand-mark">H<span>✳</span></span>
          <span>hack<span className="brand-light">harbor</span><small>HACKVERSE 2026</small></span>
        </Link>
        <nav className="main-nav" aria-label="Main navigation">
          {links.map((link) => <NavLink key={link.to} to={link.to} end={link.end}>{link.label}</NavLink>)}
        </nav>
        <div className="top-actions">
          <span className={`api-status api-${apiStatus}`} title={apiError || 'HackHarbor server status'}><i />{apiStatus === 'online' ? 'SERVER LIVE' : apiStatus === 'connecting' ? 'CONNECTING' : 'SERVER OFFLINE'}</span>
          {isJudge && <button className="judge-pill" onClick={logoutJudge}>Judge mode · Sign out</button>}
          <button className="theme-toggle" onClick={toggleTheme} aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`} title="Toggle theme">{theme === 'dark' ? '☼' : '☾'}</button>
          <Link className="button button-small button-primary nav-cta" to="/register">Join the build <span>↗</span></Link>
        </div>
      </header>
      <main><Outlet /></main>
      <footer className="footer">
        <div className="footer-brand"><span className="brand-mark">H<span>✳</span></span><div><strong>HackHarbor</strong><small>Build boldly. Ship brilliantly.</small></div></div>
        <p>Made for makers, by makers. <span>© 2026 HackVerse</span></p>
        <div className="footer-links"><Link to="/leaderboard">Live results</Link><Link to="/judge">Judge portal</Link><a href="mailto:hello@hackharbor.dev">Contact</a></div>
      </footer>
    </div>
  );
}
