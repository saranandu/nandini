import { Component } from 'react';

export default class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error, info) {
    // Keep the error visible to local development tools without exposing internals to visitors.
    console.error('HackHarbor UI error:', error, info.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return <main className="page-wrap empty-state"><span className="section-kicker">SAFE RECOVERY</span><h1>Something went<br /><span className="muted-heading">off course.</span></h1><p>The page hit an unexpected error. Your saved server data has not been cleared.</p><button className="button button-primary" onClick={() => window.location.reload()}>Reload HackHarbor ↗</button></main>;
    }
    return this.props.children;
  }
}
