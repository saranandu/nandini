import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { createSeedData } from '../data/seed';
import { apiRequest, clearJudgeToken, getJudgeToken, getTeamToken, setJudgeToken, setTeamToken } from '../utils/api';

const HackathonContext = createContext(null);
const THEME_KEY = 'hackharbor-theme';

function readTheme() {
  try { return localStorage.getItem(THEME_KEY) || 'dark'; }
  catch { return 'dark'; }
}

export function HackathonProvider({ children }) {
  const [data, setData] = useState(createSeedData);
  const [deadlines, setDeadlines] = useState({ registration: null, submission: null, judging: null });
  const [apiStatus, setApiStatus] = useState('connecting');
  const [apiError, setApiError] = useState('');
  const [isJudge, setIsJudge] = useState(false);
  const [judge, setJudge] = useState(null);
  const [theme, setTheme] = useState(readTheme);

  const refreshData = useCallback(async () => {
    const payload = await apiRequest('/api/bootstrap');
    setData(payload.data);
    setDeadlines(payload.deadlines || {});
    setApiStatus('online');
    setApiError('');
    return payload.data;
  }, []);

  useEffect(() => {
    let active = true;
    const load = async () => {
      try {
        const payload = await apiRequest('/api/bootstrap');
        if (active) {
          setData(payload.data);
          setDeadlines(payload.deadlines || {});
          setApiStatus('online');
          setApiError('');
        }
      } catch (error) {
        if (active) {
          setApiStatus('offline');
          setApiError(error.message);
        }
      }
      const token = getJudgeToken();
      if (!token || !active) return;
      try {
        const session = await apiRequest('/api/auth/me', { token });
        if (active) { setJudge(session.judge); setIsJudge(true); }
      } catch {
        clearJudgeToken();
        if (active) { setJudge(null); setIsJudge(false); }
      }
    };
    load();
    return () => { active = false; };
  }, []);

  useEffect(() => {
    const poll = window.setInterval(() => {
      refreshData().catch((error) => { setApiStatus('offline'); setApiError(error.message); });
    }, 5000);
    return () => window.clearInterval(poll);
  }, [refreshData]);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    try { localStorage.setItem(THEME_KEY, theme); }
    catch { /* Theme continues to work for the current tab. */ }
  }, [theme]);

  const addTeam = useCallback(async (team) => {
    const result = await apiRequest('/api/teams', { method: 'POST', body: team });
    setTeamToken(result.team.id, result.teamToken);
    await refreshData();
    return result;
  }, [refreshData]);

  const addTeamMember = useCallback(async (teamId, member, inviteToken) => {
    const result = await apiRequest(`/api/teams/${encodeURIComponent(teamId)}/join`, {
      method: 'POST', body: { ...member, token: inviteToken || '' },
    });
    setTeamToken(result.team.id, result.teamToken);
    await refreshData();
    return result.team;
  }, [refreshData]);

  const addProject = useCallback(async (project) => {
    const teamToken = getTeamToken(project.teamId);
    if (!teamToken) throw new Error('This browser does not have team access. Register the team or open its private invitation link to join before submitting.');
    const result = await apiRequest('/api/projects', { method: 'POST', body: project, teamToken });
    await refreshData();
    return result.project;
  }, [refreshData]);

  const saveScore = useCallback(async (score) => {
    try {
      const result = await apiRequest('/api/scores', { method: 'POST', body: score });
      await refreshData();
      return result.score;
    } catch (error) {
      if (error.status === 401) { clearJudgeToken(); setJudge(null); setIsJudge(false); }
      throw error;
    }
  }, [refreshData]);

  const loginJudge = useCallback(async (email, password) => {
    const result = await apiRequest('/api/auth/judge', { method: 'POST', body: { email, password }, token: '' });
    setJudgeToken(result.token);
    setJudge(result.judge);
    setIsJudge(true);
    await refreshData();
    return result.judge;
  }, [refreshData]);

  const logoutJudge = useCallback(() => {
    clearJudgeToken();
    setJudge(null);
    setIsJudge(false);
  }, []);

  const toggleTheme = useCallback(() => setTheme((current) => current === 'dark' ? 'light' : 'dark'), []);

  const value = useMemo(() => ({
    data, deadlines, apiStatus, apiError, refreshData, hasTeamAccess: (teamId) => Boolean(getTeamToken(teamId)),
    addTeam, addTeamMember, addProject, saveScore,
    isJudge, judge, loginJudge, logoutJudge,
    theme, toggleTheme,
  }), [data, deadlines, apiStatus, apiError, refreshData, addTeam, addTeamMember, addProject, saveScore, isJudge, judge, loginJudge, logoutJudge, theme, toggleTheme]);

  return <HackathonContext.Provider value={value}>{children}</HackathonContext.Provider>;
}

export function useHackathon() {
  const context = useContext(HackathonContext);
  if (!context) throw new Error('useHackathon must be used inside HackathonProvider');
  return context;
}
