import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { HackathonProvider } from './context/HackathonContext';
import Layout from './components/Layout';
import Home from './pages/Home';
import Register from './pages/Register';
import Submit from './pages/Submit';
import Judge from './pages/Judge';
import Leaderboard from './pages/Leaderboard';

export default function App() {
  return <HackathonProvider><BrowserRouter><Routes><Route element={<Layout />}><Route index element={<Home />} /><Route path="register" element={<Register />} /><Route path="submit" element={<Submit />} /><Route path="judge" element={<Judge />} /><Route path="leaderboard" element={<Leaderboard />} /><Route path="*" element={<main className="page-wrap empty-state"><h1>Page not found.</h1><a className="text-link" href="/">Back home ↗</a></main>} /></Route></Routes></BrowserRouter></HackathonProvider>;
}
