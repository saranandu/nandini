const roster = (leader, email, extra = []) => [
  { name: leader, email, role: 'Team lead' },
  ...extra.map((member) => ({ ...member, role: 'Member' })),
];

export function createSeedData() {
  const teams = [
    { id: 'team-quantum', name: 'QuantumCoders', track: 'Healthcare', leader: 'Aarav Sharma', email: 'aarav@example.com', members: roster('Aarav Sharma', 'aarav@example.com', [{ name: 'Diya Patel', email: 'diya@example.com' }, { name: 'Kabir Rao', email: 'kabir@example.com' }]), createdAt: '2026-11-10T10:00:00.000Z' },
    { id: 'team-byte', name: 'ByteBuilders', track: 'EdTech', leader: 'Mira Nair', email: 'mira@example.com', members: roster('Mira Nair', 'mira@example.com', [{ name: 'Dev Shah', email: 'dev@example.com' }]), createdAt: '2026-11-10T11:00:00.000Z' },
    { id: 'team-finnova', name: 'FinNova', track: 'Fintech', leader: 'Ishaan Gupta', email: 'ishaan@example.com', members: roster('Ishaan Gupta', 'ishaan@example.com'), createdAt: '2026-11-10T12:00:00.000Z' },
    { id: 'team-chain', name: 'ChainReaction', track: 'Web3', leader: 'Sara Khan', email: 'sara@example.com', members: roster('Sara Khan', 'sara@example.com', [{ name: 'Arjun Das', email: 'arjun@example.com' }]), createdAt: '2026-11-10T13:00:00.000Z' },
    { id: 'team-pixel', name: 'PixelPioneers', track: 'Open Innovation', leader: 'Neha Reddy', email: 'neha@example.com', members: roster('Neha Reddy', 'neha@example.com', [{ name: 'Vikram Bose', email: 'vikram@example.com' }]), createdAt: '2026-11-10T14:00:00.000Z' },
    { id: 'team-circuit', name: 'CircuitBreakers', track: 'Healthcare', leader: 'Aditi Menon', email: 'aditi@example.com', members: roster('Aditi Menon', 'aditi@example.com'), createdAt: '2026-11-10T15:00:00.000Z' },
    { id: 'team-cloud', name: 'CloudNine', track: 'EdTech', leader: 'Reyansh Verma', email: 'reyansh@example.com', members: roster('Reyansh Verma', 'reyansh@example.com'), createdAt: '2026-11-10T16:00:00.000Z' },
    { id: 'team-ledger', name: 'LedgerLabs', track: 'Fintech', leader: 'Tara Joseph', email: 'tara@example.com', members: roster('Tara Joseph', 'tara@example.com'), createdAt: '2026-11-10T17:00:00.000Z' },
    { id: 'team-orbit', name: 'OrbitWorks', track: 'Web3', leader: 'Kunal Mehta', email: 'kunal@example.com', members: roster('Kunal Mehta', 'kunal@example.com'), createdAt: '2026-11-10T18:00:00.000Z' },
    { id: 'team-spark', name: 'SparkShift', track: 'Open Innovation', leader: 'Anaya Sen', email: 'anaya@example.com', members: roster('Anaya Sen', 'anaya@example.com'), createdAt: '2026-11-10T19:00:00.000Z' },
    { id: 'team-neural', name: 'NeuralNest', track: 'Healthcare', leader: 'Advik Jain', email: 'advik@example.com', members: roster('Advik Jain', 'advik@example.com'), createdAt: '2026-11-10T20:00:00.000Z' },
    { id: 'team-frontend', name: 'FrontendFables', track: 'EdTech', leader: 'Myra Thomas', email: 'myra@example.com', members: roster('Myra Thomas', 'myra@example.com'), createdAt: '2026-11-10T21:00:00.000Z' },
  ];

  const projects = [
    { id: 'project-cardio', teamId: 'team-quantum', title: 'CardioScan', tagline: 'A clearer picture of heart health, powered by accessible AI.', github: 'https://github.com/example/cardioscan', demo: 'https://example.com/cardioscan', video: 'https://youtube.com/watch?v=demo', stack: ['React', 'Python', 'Machine Learning'], createdAt: '2026-11-11T10:00:00.000Z' },
    { id: 'project-learn', teamId: 'team-byte', title: 'LearnLoop', tagline: 'Small learning loops that adapt to every student.', github: 'https://github.com/example/learnloop', demo: 'https://example.com/learnloop', video: '', stack: ['React', 'Node.js', 'AI'], createdAt: '2026-11-11T11:00:00.000Z' },
    { id: 'project-spend', teamId: 'team-finnova', title: 'SpendWise', tagline: 'Make everyday money decisions easier to understand.', github: 'https://github.com/example/spendwise', demo: '', video: '', stack: ['TypeScript', 'Firebase'], createdAt: '2026-11-11T12:00:00.000Z' },
    { id: 'project-proof', teamId: 'team-chain', title: 'ProofPass', tagline: 'Portable credentials for a more trusted digital world.', github: 'https://github.com/example/proofpass', demo: 'https://example.com/proofpass', video: '', stack: ['Solidity', 'React', 'Web3'], createdAt: '2026-11-11T13:00:00.000Z' },
    { id: 'project-civic', teamId: 'team-pixel', title: 'CivicFlow', tagline: 'A simpler way to report and follow local issues.', github: 'https://github.com/example/civicflow', demo: 'https://example.com/civicflow', video: '', stack: ['React', 'Maps API'], createdAt: '2026-11-11T14:00:00.000Z' },
    { id: 'project-pulse', teamId: 'team-circuit', title: 'PulsePath', tagline: 'A connected care journey for community clinics.', github: 'https://github.com/example/pulsepath', demo: '', video: '', stack: ['Flutter', 'Node.js'], createdAt: '2026-11-11T15:00:00.000Z' },
    { id: 'project-classroom', teamId: 'team-cloud', title: 'ClassroomOS', tagline: 'One calm workspace for teachers and learners.', github: 'https://github.com/example/classroomos', demo: 'https://example.com/classroomos', video: '', stack: ['Next.js', 'Supabase'], createdAt: '2026-11-11T16:00:00.000Z' },
    { id: 'project-ledger', teamId: 'team-ledger', title: 'OpenLedger', tagline: 'Understand cash flow without the spreadsheet maze.', github: 'https://github.com/example/openledger', demo: '', video: '', stack: ['Vue', 'Python'], createdAt: '2026-11-11T17:00:00.000Z' },
  ];

  const scores = [
    // Demo scores make the leaderboard populated before a live judging walkthrough.
    { id: 'score-1', projectId: 'project-cardio', judgeId: 'judge-rao', innovation: 8, complexity: 8, uiux: 8, presentation: 8, note: 'Strong direction and thoughtful implementation.' },
    { id: 'score-2', projectId: 'project-cardio', judgeId: 'judge-shah', innovation: 8, complexity: 7, uiux: 9, presentation: 8, note: 'Clear experience with room to deepen the demo.' },
    { id: 'score-3', projectId: 'project-learn', judgeId: 'judge-mehta', innovation: 9, complexity: 8, uiux: 9, presentation: 9, note: 'Compelling learning experience.' },
    { id: 'score-4', projectId: 'project-learn', judgeId: 'judge-iyer', innovation: 8, complexity: 8, uiux: 9, presentation: 8, note: 'Good product story.' },
    { id: 'score-5', projectId: 'project-spend', judgeId: 'judge-rao', innovation: 8, complexity: 9, uiux: 7, presentation: 8, note: 'Solid technical execution.' },
    { id: 'score-6', projectId: 'project-spend', judgeId: 'judge-mehta', innovation: 8, complexity: 8, uiux: 8, presentation: 8, note: 'Useful problem choice.' },
    { id: 'score-7', projectId: 'project-proof', judgeId: 'judge-shah', innovation: 8, complexity: 8, uiux: 8, presentation: 7, note: 'Interesting application of verifiable credentials.' },
    { id: 'score-8', projectId: 'project-proof', judgeId: 'judge-iyer', innovation: 9, complexity: 9, uiux: 7, presentation: 8, note: 'Promising technical direction.' },
    { id: 'score-9', projectId: 'project-civic', judgeId: 'judge-mehta', innovation: 8, complexity: 7, uiux: 8, presentation: 8, note: 'Strong community value.' },
    { id: 'score-10', projectId: 'project-civic', judgeId: 'judge-rao', innovation: 7, complexity: 8, uiux: 8, presentation: 8, note: 'Good prototype scope.' },
    { id: 'score-11', projectId: 'project-pulse', judgeId: 'judge-shah', innovation: 7, complexity: 8, uiux: 8, presentation: 7, note: 'Promising care workflow.' },
    { id: 'score-12', projectId: 'project-classroom', judgeId: 'judge-iyer', innovation: 8, complexity: 7, uiux: 9, presentation: 8, note: 'Polished classroom concept.' },
    { id: 'score-13', projectId: 'project-ledger', judgeId: 'judge-mehta', innovation: 7, complexity: 8, uiux: 7, presentation: 8, note: 'Clear financial utility.' },
  ];

  return { teams, projects, scores };
}
