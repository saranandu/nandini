// Change these values to match your actual event details.
export const EVENT_CONFIG = {
  name: 'HackVerse 2026',
  edition: '01 / COMMUNITY BUILD',
  // Demo placeholder: update this to your real event date and time.
  countdownTarget: '2026-12-12T09:00:00+05:30',
  prizePool: '$10,000',
};

export const TRACKS = [
  { id: 'Fintech', icon: '◈', color: 'cyan', title: 'Fintech', description: 'Reimagine payments, personal finance, banking and financial inclusion.', tags: ['Payments', 'DeFi', 'Financial access'] },
  { id: 'EdTech', icon: '▤', color: 'violet', title: 'EdTech', description: 'Make learning more personal, accessible and effective for everyone.', tags: ['Personalized learning', 'Accessibility', 'Assessment'] },
  { id: 'Healthcare', icon: '✚', color: 'pink', title: 'Healthcare', description: 'Build thoughtful technology for healthier communities and better care.', tags: ['Patient care', 'Diagnostics', 'Wellness'] },
  { id: 'Web3', icon: '⬡', color: 'orange', title: 'Web3', description: 'Explore trust, ownership and coordination on the decentralized web.', tags: ['Identity', 'Smart contracts', 'Transparency'] },
  { id: 'Open Innovation', icon: '✳', color: 'green', title: 'Open Innovation', description: 'Take on any meaningful challenge with a bold, original solution.', tags: ['Civic tech', 'Climate', 'Wildcard'] },
];

export const JUDGES = [
  { id: 'judge-mehta', name: 'Dr. Mehta', title: 'Product & Innovation' },
  { id: 'judge-rao', name: 'Ananya Rao', title: 'Engineering' },
  { id: 'judge-shah', name: 'Rohan Shah', title: 'Design & Experience' },
  { id: 'judge-iyer', name: 'Priya Iyer', title: 'Startup & Pitch' },
];

export const RUBRIC = [
  { key: 'innovation', label: 'Innovation', weight: 30, hint: 'Originality, relevance and problem insight.' },
  { key: 'complexity', label: 'Technical complexity', weight: 30, hint: 'Engineering depth and technical execution.' },
  { key: 'uiux', label: 'UI / UX', weight: 20, hint: 'Usability, accessibility and visual clarity.' },
  { key: 'presentation', label: 'Presentation', weight: 20, hint: 'Demo quality, storytelling and clarity.' },
];
