import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { EVENT_CONFIG, TRACKS } from '../data/eventConfig';
import { useHackathon } from '../context/HackathonContext';

const faqs = [
  { q: 'Who can participate?', a: 'Students, curious builders and early-stage makers are welcome. Bring a team or register solo and start connecting with other participants.' },
  { q: 'How large can a team be?', a: 'Teams can have up to four members, including the team lead. You can register your roster from the Team Registration page.' },
  { q: 'Can we submit an existing project?', a: 'Your submission should be built or meaningfully developed for this hackathon. Make sure your demo clearly explains what your team created during the event.' },
  { q: 'How will projects be judged?', a: 'Projects are scored from 1–10 across Innovation (30%), Technical Complexity (30%), UI/UX (20%) and Presentation (20%).' },
  { q: 'Where can I see the results?', a: 'The Live Leaderboard shows the current ranked teams, their track and average judging score. Scores update when judges submit evaluations.' },
];

function Countdown() {
  const target = new Date(EVENT_CONFIG.countdownTarget).getTime();
  const [remaining, setRemaining] = useState(Math.max(0, target - Date.now()));
  useEffect(() => {
    const timer = window.setInterval(() => setRemaining(Math.max(0, target - Date.now())), 1000);
    return () => window.clearInterval(timer);
  }, [target]);
  const units = [
    ['DAYS', Math.floor(remaining / 86400000)],
    ['HRS', Math.floor((remaining / 3600000) % 24)],
    ['MIN', Math.floor((remaining / 60000) % 60)],
    ['SEC', Math.floor((remaining / 1000) % 60)],
  ];
  return <div className="countdown" aria-label="Countdown to event start">{units.map(([label, value]) => <div className="time-unit" key={label}><strong>{String(value).padStart(2, '0')}</strong><small>{label}</small></div>)}</div>;
}

export default function Home() {
  const { data } = useHackathon();
  const [openFaq, setOpenFaq] = useState(0);
  const submitted = data.projects.length;
  return (
    <>
      <section className="hero section-wrap">
        <div className="hero-grid-bg" />
        <div className="hero-copy">
          <div className="eyebrow"><span className="live-dot" /> {EVENT_CONFIG.edition}</div>
          <h1>Ideas don't<br />ship themselves<span className="gradient-text">.</span></h1>
          <p className="hero-lede">A meeting point for the curious, the courageous and the “what if?” thinkers. Find your people, build something real, and put it out into the world.</p>
          <div className="hero-actions"><Link to="/register" className="button button-primary">Register your team <span>↗</span></Link><Link to="/leaderboard" className="button button-ghost">Explore leaderboard <span>→</span></Link></div>
          <div className="hero-proof"><div className="avatar-stack"><i>AK</i><i>MN</i><i>SG</i><i>+9</i></div><span><strong>{data.teams.length} teams</strong> already in the harbor</span><span className="proof-divider" /><span className="mono">{submitted} PROJECTS SUBMITTED</span></div>
        </div>
        <div className="hero-visual" aria-label="Hackathon event countdown">
          <div className="orbit orbit-one" /><div className="orbit orbit-two" /><div className="orbit orbit-three" />
          <div className="hero-emblem"><span className="emblem-symbol">H<span>✳</span></span><strong>HACK<br />THE<br />FUTURE</strong><small>HACKVERSE / 2026</small></div>
          <div className="floating-tag tag-top"><span className="tag-dot cyan-dot" /> OPEN INNOVATION</div>
          <div className="floating-tag tag-bottom"><span className="tag-dot violet-dot" /> BUILD · BREAK · REPEAT</div>
          <div className="hero-coordinate mono">17° 26' N<br />78° 26' E</div>
        </div>
        <div className="hero-bottomline"><span>SCROLL TO EXPLORE <b>↓</b></span><span className="mono">COMMUNITY · BUILD · SHARE</span></div>
      </section>

      <section className="ticker-band"><div className="ticker-track">{Array.from({ length: 2 }).map((_, i) => <span key={i}>BUILD SOMETHING THAT MATTERS <b>✳</b> FIND YOUR PEOPLE <b>✳</b> MAKE THE IMPOSSIBLE DEMO-ABLE <b>✳</b> SHIP IT INTO THE WORLD <b>✳</b></span>)}</div></section>

      <section className="section-wrap event-strip" id="about">
        <div><span className="section-kicker">THE EVENT</span><h2>One big<br /><span className="muted-heading">beautiful challenge.</span></h2></div>
        <div className="event-intro"><p>HackVerse is where raw ideas become working prototypes. Bring a problem worth solving, a team that thinks differently, and the energy to make something happen.</p><Link className="text-link" to="/register">Find your starting point <span>↗</span></Link></div>
        <div className="event-numbers"><div><strong>{data.teams.length.toString().padStart(2, '0')}</strong><small>REGISTERED TEAMS</small></div><div><strong>05</strong><small>CHALLENGE TRACKS</small></div><div><strong>{EVENT_CONFIG.prizePool}</strong><small>TOTAL PRIZE POOL</small></div></div>
      </section>

      <section className="section-wrap tracks-section" id="tracks">
        <div className="section-heading"><div><span className="section-kicker">PICK YOUR PLAYGROUND</span><h2>Five tracks.<br /><span className="muted-heading">Infinite directions.</span></h2></div><p>Choose the challenge that gets your brain buzzing. No perfect idea required — just a good question and the courage to explore it.</p></div>
        <div className="track-grid">{TRACKS.map((track, index) => <article className={`track-card track-${track.color}`} key={track.id}><div className="track-card-top"><span className="track-icon">{track.icon}</span><span className="mono">0{index + 1} / 05</span></div><h3>{track.title}</h3><p>{track.description}</p><div className="track-tags">{track.tags.map((tag) => <span key={tag}>{tag}</span>)}</div><Link to={`/register?track=${encodeURIComponent(track.id)}`} aria-label={`Register for ${track.title}`} className="track-arrow">↗</Link></article>)}</div>
      </section>

      <section className="prize-section" id="prizes"><div className="section-wrap prize-inner"><div><span className="section-kicker">THE GOOD STUFF</span><h2>Make it real.<br /><span className="muted-heading">Take it further.</span></h2><p className="prize-copy">A prize pool for bold thinking, thoughtful execution and ideas with somewhere to go next.</p><Link to="/register" className="button button-primary">I'm in <span>↗</span></Link></div><div className="prize-board"><div className="prize-total"><small>TOTAL PRIZE POOL</small><strong>{EVENT_CONFIG.prizePool}</strong><span>IN CASH, CREDITS & SWAG</span></div><div className="prize-podium"><div className="podium-place second"><span>02</span><strong>$2,500</strong><small>RUNNER UP</small></div><div className="podium-place first"><span>01</span><strong>$5,000</strong><small>GRAND PRIZE</small></div><div className="podium-place third"><span>03</span><strong>$1,500</strong><small>THIRD PLACE</small></div></div><div className="prize-note mono">+ TRACK AWARDS, MENTOR HOURS & PARTNER PERKS</div></div></div></section>

      <section className="section-wrap countdown-section"><div><span className="section-kicker">THE CLOCK IS TICKING</span><h2>Every great build<br /><span className="muted-heading">starts somewhere.</span></h2><p className="muted-copy">Get your team ready. The next big idea could be yours.</p></div><div className="countdown-panel"><div className="countdown-label"><span className="live-dot" /> EVENT COUNTDOWN <span className="mono">HACKVERSE 2026</span></div><Countdown /><small className="countdown-footnote">Demo date is configurable in <code>src/data/eventConfig.js</code>.</small></div></section>

      <section className="section-wrap faq-section" id="faq"><div className="faq-intro"><span className="section-kicker">GOOD TO KNOW</span><h2>Questions?<br /><span className="muted-heading">We've got you.</span></h2><p>One less thing between you and building something brilliant.</p><a className="text-link" href="mailto:hello@hackharbor.dev">Ask the team <span>↗</span></a></div><div className="faq-list">{faqs.map((faq, index) => <article className={`faq-item ${openFaq === index ? 'faq-open' : ''}`} key={faq.q}><button onClick={() => setOpenFaq(openFaq === index ? -1 : index)} aria-expanded={openFaq === index}><span className="mono">0{index + 1}</span><strong>{faq.q}</strong><span className="faq-plus">{openFaq === index ? '−' : '+'}</span></button>{openFaq === index && <p>{faq.a}</p>}</article>)}</div></section>

      <section className="section-wrap final-cta"><div className="cta-spark">✳</div><span className="section-kicker">YOUR NEXT CHAPTER STARTS HERE</span><h2>Less talking.<br /><span className="gradient-text">More making.</span></h2><Link className="button button-primary" to="/register">Claim your spot <span>↗</span></Link><span className="cta-orbit orbit-a" /><span className="cta-orbit orbit-b" /></section>
    </>
  );
}
