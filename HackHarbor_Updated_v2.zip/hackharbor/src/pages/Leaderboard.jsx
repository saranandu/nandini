import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { TRACKS } from '../data/eventConfig';
import { useHackathon } from '../context/HackathonContext';
import { getLeaderboard } from '../utils/scoring';

export default function Leaderboard() {
  const { data } = useHackathon();
  const [track, setTrack] = useState('All tracks');
  const rows = useMemo(() => getLeaderboard(data, track), [data, track]);
  const scoredRows = rows.filter((item) => item.scored);
  const podium = [scoredRows[1], scoredRows[0], scoredRows[2]].filter(Boolean);
  const projectCount = data.projects.length;
  return <div className="page-wrap leaderboard-page"><div className="page-heading leaderboard-heading"><div><span className="section-kicker"><span className="live-dot" /> 04 / LIVE COMPETITION</span><h1>The leaderboard<span className="gradient-text">.</span></h1><p>Every idea has a score. Every score moves the story. Watch the teams rise.</p></div><div className="leaderboard-live-tag"><span className="live-dot" /> LIVE UPDATES<small>SYNCED ACROSS OPEN TABS</small></div></div>
    <div className="leader-stats"><div><span>REGISTERED TEAMS</span><strong>{data.teams.length.toString().padStart(2, '0')}</strong></div><div><span>PROJECTS SUBMITTED</span><strong>{projectCount.toString().padStart(2, '0')}</strong></div><div><span>EVALUATIONS</span><strong>{data.scores.length.toString().padStart(2, '0')}</strong></div><div><span>TRACKS</span><strong>05</strong></div></div>
    {podium.length > 0 && <section className="podium-section"><div className="podium-section-heading"><div><span className="section-kicker">THE FRONT RUNNERS</span><h2>Top of the harbor</h2></div><span className="mono">BASED ON WEIGHTED AVERAGE</span></div><div className="leader-podium">{podium.map((team, index) => { const rank = index === 0 ? 2 : index === 1 ? 1 : 3; return <article key={team.id} className={`leader-podium-card rank-${rank}`}><div className="podium-rank">{rank === 1 ? '✦' : `0${rank}`}</div><span className="podium-track">{team.track}</span><h3>{team.name}</h3><p>{team.project?.title || 'Project pending'}</p><div className="podium-score"><strong>{team.score.toFixed(1)}</strong><small>/ 100</small></div><div className="podium-bar" /></article>; })}</div></section>}
    <section className="rankings-section"><div className="rankings-head"><div><span className="section-kicker">THE FULL FIELD</span><h2>All teams</h2></div><label className="filter-field"><span>FILTER BY TRACK</span><select value={track} onChange={(e) => setTrack(e.target.value)}><option>All tracks</option>{TRACKS.map((item) => <option key={item.id}>{item.id}</option>)}</select></label></div>
      <div className="leader-table-wrap"><table className="leader-table"><thead><tr><th>RANK</th><th>TEAM / PROJECT</th><th>TRACK</th><th>JUDGES</th><th>CONSENSUS</th><th className="score-col">SCORE <small>/ 100</small></th></tr></thead><tbody>{rows.map((team, index) => <tr key={team.id} className={`leader-row ${team.scored ? '' : 'not-scored'}`}><td><span className={`rank-number ${index < 3 && team.scored ? 'top-rank' : ''}`}>{team.scored ? String(index + 1).padStart(2, '0') : '—'}</span></td><td><div className="team-project-cell"><strong>{team.name}</strong><span>{team.project?.title || 'Awaiting project submission'}</span></div></td><td><span className="track-chip">{team.track}</span></td><td><span className="judge-count">{team.scoreCount} {team.scoreCount === 1 ? 'score' : 'scores'}</span></td><td><span className={`consensus-pill consensus-${team.consensus.key}`}>{team.consensus.label}</span>{team.consensus.outlierCount > 0 && <small className="consensus-warning">{team.consensus.outlierCount} outlier(s)</small>}</td><td className="score-col"><strong>{team.scored ? team.score.toFixed(1) : '—'}</strong><div className="mini-score-track"><i style={{ width: `${team.score}%` }} /></div></td></tr>)}</tbody></table>{!rows.length && <div className="empty-state"><p>No teams in this track yet.</p></div>}</div>
    </section>
    <div className="leaderboard-bottom-note"><span className="live-dot" /><p>Scores are averages of all submitted judge evaluations. New evaluations update the leaderboard automatically.</p><Link to="/judge">Open judging console ↗</Link></div>
  </div>;
}
