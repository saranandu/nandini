import { useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { TRACKS } from '../data/eventConfig';
import { useHackathon } from '../context/HackathonContext';

const emptyMember = () => ({ name: '', email: '' });
const deadlinePassed = (value) => Boolean(value) && Number.isFinite(Date.parse(value)) && Date.now() > Date.parse(value);

export default function Register() {
  const { data, deadlines, addTeam, addTeamMember } = useHackathon();
  const [params] = useSearchParams();
  const inviteId = params.get('invite');
  const inviteToken = params.get('token');
  const inviteMode = Boolean(inviteId);
  const registrationClosed = deadlinePassed(deadlines.registration);
  const inviteTeam = data.teams.find((team) => team.id === inviteId);
  const [teamName, setTeamName] = useState('');
  const [track, setTrack] = useState(TRACKS.some((item) => item.id === params.get('track')) ? params.get('track') : 'Open Innovation');
  const [leader, setLeader] = useState('');
  const [email, setEmail] = useState('');
  const [members, setMembers] = useState([emptyMember()]);
  const [error, setError] = useState('');
  const [createdTeam, setCreatedTeam] = useState(null);
  const [createdInviteToken, setCreatedInviteToken] = useState('');
  const [inviteName, setInviteName] = useState('');
  const [inviteEmail, setInviteEmail] = useState('');
  const [joinedTeam, setJoinedTeam] = useState('');

  const updateMember = (index, key, value) => setMembers((current) => current.map((member, i) => i === index ? { ...member, [key]: value } : member));
  const addMember = () => { if (members.length < 3) setMembers((current) => [...current, emptyMember()]); };
  const removeMember = (index) => setMembers((current) => current.filter((_, i) => i !== index));

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError('');
    const roster = [
      { name: leader.trim(), email: email.trim(), role: 'Team lead' },
      ...members.filter((member) => member.name.trim() || member.email.trim()).map((member) => ({ name: member.name.trim(), email: member.email.trim(), role: 'Member' })),
    ];
    if (!teamName.trim() || !leader.trim() || !email.trim()) return setError('Please complete the team name and team lead details.');
    if (roster.slice(1).some((member) => !member.name || !member.email)) return setError('Add both a name and email for each teammate, or remove the empty row.');
    if (roster.length > 4) return setError('A team can have a maximum of four members, including the lead.');
    const emails = roster.map((member) => member.email.toLowerCase());
    if (new Set(emails).size !== emails.length) return setError('Each team member must use a different email address.');
    if (data.teams.some((team) => team.name.toLowerCase() === teamName.trim().toLowerCase())) return setError('That team name is already taken. Choose another name.');
    try {
      const result = await addTeam({ name: teamName.trim(), track, leader: leader.trim(), email: email.trim(), members: roster });
      setCreatedTeam(result.team);
      setCreatedInviteToken(result.inviteToken);
    } catch (requestError) { setError(requestError.message); }
  };

  const handleJoinTeam = async (event) => {
    event.preventDefault();
    setError('');
    if (!inviteTeam) return setError('This team invite could not be found. Ask the team lead for a fresh link.');
    if ((inviteTeam.memberCount ?? inviteTeam.members?.length ?? 0) >= 4) return setError('This team roster is already full.');
    if (!inviteName.trim() || !inviteEmail.trim()) return setError('Enter your name and email to join this team.');
    try {
      const joined = await addTeamMember(inviteTeam.id, { name: inviteName.trim(), email: inviteEmail.trim() }, inviteToken);
      setJoinedTeam(joined.name);
    } catch (requestError) { setError(requestError.message); }
  };

  const inviteUrl = createdTeam ? `${window.location.origin}/register?invite=${encodeURIComponent(createdTeam.id)}&token=${encodeURIComponent(createdInviteToken)}` : '';
  const copyInvite = async () => {
    try { await navigator.clipboard.writeText(inviteUrl); setError('Invite link copied to clipboard.'); }
    catch { setError(`Copy this invite link: ${inviteUrl}`); }
  };

  return (
    <div className="page-wrap form-page">
      <div className="page-heading"><span className="section-kicker">01 / TEAM REGISTRATION</span><h1>Find your people.<br /><span className="muted-heading">Make your mark.</span></h1><p>Every good build starts with a team that cares about the problem. Get your crew on the list.</p></div>
      {registrationClosed && <div className="notice-banner">Team registration is closed. The server has locked new registrations after the published deadline.</div>}
      {inviteMode && !inviteTeam && <div className="notice-banner">This team invite could not be found in the current event.</div>}
      {inviteMode && inviteTeam && (joinedTeam ? <section className="success-card"><div className="success-icon">✓</div><span className="section-kicker">ROSTER UPDATED</span><h2>You're in<br /><span className="muted-heading">{joinedTeam}.</span></h2><p>Your name has been added to this team's roster on the HackHarbor server.</p><Link to="/submit" className="button button-primary">Continue to project submission <span>↗</span></Link></section> : <form className="form-card invite-join-card" onSubmit={handleJoinTeam}><div className="form-card-title"><div><span className="section-kicker">SECURE TEAM INVITATION</span><h2>Join {inviteTeam.name}</h2></div><span className="form-step mono">{inviteTeam.memberCount ?? inviteTeam.members?.length ?? 1} / 4 MEMBERS</span></div><p className="muted-copy">You're joining the <strong>{inviteTeam.track}</strong> team. Add your details to the roster.</p><div className="field-grid"><label className="field"><span>YOUR NAME *</span><input value={inviteName} onChange={(e) => setInviteName(e.target.value)} placeholder="Your full name" required /></label><label className="field"><span>YOUR EMAIL *</span><input type="email" value={inviteEmail} onChange={(e) => setInviteEmail(e.target.value)} placeholder="you@example.com" required /></label></div>{error && <p className="form-error">{error}</p>}<div className="form-footer"><p>Invite token is verified by the server and expires automatically.</p><button type="submit" className="button button-primary" disabled={registrationClosed}>Join team <span>↗</span></button></div></form>)}
      {!inviteMode && createdTeam ? <section className="success-card"><div className="success-icon">✓</div><span className="section-kicker">YOU'RE ON THE LIST</span><h2>{createdTeam.name}<br /><span className="muted-heading">is ready to build.</span></h2><p>Your team has been registered for <strong>{createdTeam.track}</strong>. Share the private invite link with your teammates.</p><div className="invite-link-box"><code>{inviteUrl}</code><button className="button button-small button-primary" onClick={copyInvite}>Copy link</button><a className="button button-small button-ghost" href={`mailto:?subject=${encodeURIComponent(`Join ${createdTeam.name} on HackVerse 2026`)}&body=${encodeURIComponent(`You have been invited to join ${createdTeam.name}. Open this link to join the roster: ${inviteUrl}`)}`}>Email invite ↗</a></div>{error && <p className="form-success">{error}</p>}<div className="success-actions"><Link to="/submit" className="button button-primary">Submit your idea <span>↗</span></Link><button className="button button-ghost" onClick={() => { setCreatedTeam(null); setCreatedInviteToken(''); setTeamName(''); setLeader(''); setEmail(''); setMembers([emptyMember()]); }}>Register another team</button></div></section> : (!inviteMode && (
        <form className="form-card" onSubmit={handleSubmit}>
          <div className="form-card-title"><div><span className="section-kicker">YOUR CREW</span><h2>Team details</h2></div><span className="form-step mono">STEP 01 — 02</span></div>
          <div className="field-grid"><label className="field full-field"><span>TEAM NAME <b>*</b></span><input value={teamName} onChange={(e) => setTeamName(e.target.value)} placeholder="e.g. QuantumCoders" maxLength={36} required /></label><label className="field"><span>CHALLENGE TRACK <b>*</b></span><select value={track} onChange={(e) => setTrack(e.target.value)}>{TRACKS.map((item) => <option key={item.id}>{item.id}</option>)}</select></label><label className="field"><span>TEAM SIZE</span><div className="static-field">{1 + members.filter((m) => m.name.trim() || m.email.trim()).length} / 4 members</div></label><label className="field"><span>TEAM LEAD NAME <b>*</b></span><input value={leader} onChange={(e) => setLeader(e.target.value)} placeholder="Your full name" required /></label><label className="field"><span>TEAM LEAD EMAIL <b>*</b></span><input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" required /></label></div>
          <div className="roster-heading"><div><span className="section-kicker">THE REST OF THE CREW</span><h3>Teammates <span className="muted-inline">(optional)</span></h3></div><span className="mono">MAX 4 PEOPLE</span></div>
          <div className="member-list">{members.map((member, index) => <div className="member-row" key={index}><span className="member-number mono">0{index + 2}</span><input aria-label={`Member ${index + 1} name`} value={member.name} onChange={(e) => updateMember(index, 'name', e.target.value)} placeholder="Teammate name" /><input aria-label={`Member ${index + 1} email`} type="email" value={member.email} onChange={(e) => updateMember(index, 'email', e.target.value)} placeholder="Teammate email" />{members.length > 1 && <button type="button" className="remove-member" onClick={() => removeMember(index)} aria-label="Remove member">×</button>}</div>)}</div>
          {members.length < 3 && <button type="button" className="add-member" onClick={addMember}>＋ Add a teammate</button>}
          {error && <p className="form-error">{error}</p>}
          <div className="form-footer"><p>Registration is validated and saved by the event server.</p><button type="submit" className="button button-primary" disabled={registrationClosed}>Create team <span>↗</span></button></div>
        </form>
      ))}
      <div className="form-aside"><span className="aside-star">✳</span><p>Invite links are random, time-limited tokens. The server checks roster size and email uniqueness before adding a teammate.</p><Link to="/leaderboard">Explore the teams <span>↗</span></Link></div>
    </div>
  );
}
