import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { RUBRIC } from '../data/eventConfig';
import { useHackathon } from '../context/HackathonContext';
import { analyzeConsensus, scoreOutOf100 } from '../utils/scoring';

const blankScores = () => ({ innovation: 8, complexity: 8, uiux: 8, presentation: 8 });
const deadlinePassed = (value) => Boolean(value) && Number.isFinite(Date.parse(value)) && Date.now() > Date.parse(value);

export default function Judge() {
  const { data, deadlines, isJudge, judge, loginJudge, logoutJudge, saveScore } = useHackathon();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [projectId, setProjectId] = useState(data.projects[0]?.id || '');
  const [scores, setScores] = useState(blankScores);
  const [note, setNote] = useState('');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const judgingClosed = deadlinePassed(deadlines.judging);
  const project = useMemo(() => data.projects.find((item) => item.id === projectId), [data.projects, projectId]);
  const team = useMemo(() => data.teams.find((item) => item.id === project?.teamId), [data.teams, project]);
  const existingScore = data.scores.find((item) => item.projectId === projectId && item.judgeId === judge?.id);
  const preview = scoreOutOf100(scores);
  const projectConsensus = analyzeConsensus(data.scores.filter((item) => item.projectId === projectId));

  const selectProject = (id) => {
    setProjectId(id);
    const existing = data.scores.find((item) => item.projectId === id && item.judgeId === judge?.id);
    if (existing) { setScores({ innovation: existing.innovation, complexity: existing.complexity, uiux: existing.uiux, presentation: existing.presentation }); setNote(existing.note || ''); }
    else { setScores(blankScores()); setNote(''); }
    setMessage('');
  };

  const handleLogin = async (event) => {
    event.preventDefault(); setMessage(''); setBusy(true);
    try {
      const account = await loginJudge(email.trim(), password);
      setMessage(`Welcome, ${account.name}. Judge access granted.`);
      setPassword('');
    } catch (error) { setMessage(error.message); }
    finally { setBusy(false); }
  };

  const handleSave = async (event) => {
    event.preventDefault();
    if (!project) return;
    setMessage(''); setBusy(true);
    try {
      await saveScore({ projectId, ...scores, note: note.trim() });
      setMessage(`Evaluation saved for ${project.title}. The leaderboard has been updated.`);
    } catch (error) { setMessage(error.message); }
    finally { setBusy(false); }
  };

  if (!isJudge) return <div className="page-wrap judge-login-wrap"><div className="judge-login-card"><div className="judge-lock">⌑</div><span className="section-kicker">RESTRICTED AREA / JUDGES ONLY</span><h1>Welcome to the<br /><span className="muted-heading">judging console.</span></h1><p>Sign in with the judge account configured by the event administrator. Credentials are verified by the server.</p><form onSubmit={handleLogin}><label className="field"><span>JUDGE EMAIL</span><input type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="judge@example.com" required /></label><label className="field"><span>PASSWORD</span><input type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter your password" required /></label>{message && <p className="form-error">{message}</p>}<button type="submit" className="button button-primary button-full" disabled={busy}>{busy ? 'Signing in…' : 'Sign in securely'} <span>↗</span></button></form><div className="demo-credentials"><span>ACCOUNT SETUP</span><small>Set JUDGE_EMAIL and JUDGE_PASSWORD in the server .env file. No judge password is exposed in browser code.</small></div></div></div>;

  return <div className="page-wrap judge-page"><div className="page-heading compact-heading"><span className="section-kicker">03 / EVALUATION CONSOLE</span><h1>Judge the work.<br /><span className="muted-heading">Reward the thinking.</span></h1><p>Signed in as <strong>{judge?.name}</strong>. Scores are validated and saved by the server against your judge identity.</p><button type="button" className="button button-small button-ghost" onClick={logoutJudge}>Sign out ↗</button></div>
    {judgingClosed && <div className="notice-banner">Judging is closed. The server has locked new evaluations and score changes after the published deadline.</div>}
    {!data.projects.length ? <div className="empty-state"><h2>No projects yet.</h2><p>Project submissions will appear here when teams submit their work.</p><Link to="/submit" className="text-link">Go to submissions ↗</Link></div> : <div className="judge-layout"><form className="form-card judge-form" onSubmit={handleSave}><div className="form-card-title"><div><span className="section-kicker">EVALUATION SHEET</span><h2>Project scorecard</h2></div><span className="judge-status"><i /> {judgingClosed ? 'LOCKED' : 'ACTIVE'}</span></div><div className="field-grid"><label className="field full-field"><span>PROJECT TO EVALUATE</span><select value={projectId} onChange={(e) => selectProject(e.target.value)}>{data.projects.map((item) => <option value={item.id} key={item.id}>{item.title}</option>)}</select></label></div>{project && <div className="judge-project-summary"><div><span className="section-kicker">{team?.track || 'TRACK'}</span><h3>{project.title}</h3><p>{project.tagline}</p><small className={`consensus-pill consensus-${projectConsensus.key}`}>Judge signal: {projectConsensus.label}{projectConsensus.spread !== null ? ` · σ ${projectConsensus.spread}` : ''}</small></div><div className="judge-project-links"><a href={project.github} target="_blank" rel="noreferrer">GitHub ↗</a>{project.demo && <a href={project.demo} target="_blank" rel="noreferrer">Live demo ↗</a>}{project.video && <a href={project.video} target="_blank" rel="noreferrer">Video ↗</a>}</div></div>}
      <div className="rubric-heading"><div><span className="section-kicker">THE RUBRIC</span><h3>Evaluation criteria</h3></div><span className="mono">SCORE EACH 1–10</span></div>
      <div className="rubric-list">{RUBRIC.map((item) => <div className="rubric-item" key={item.key}><div className="rubric-top"><div><strong>{item.label}</strong><p>{item.hint}</p></div><div className="rubric-score"><strong>{scores[item.key]}</strong><small>/ 10</small></div></div><div className="rubric-weight"><span>{item.weight}% WEIGHT</span><input type="range" min="1" max="10" step="1" value={scores[item.key]} onChange={(e) => setScores((current) => ({ ...current, [item.key]: Number(e.target.value) }))} aria-label={`${item.label} score`} /><div className="range-labels"><span>1 · Needs work</span><span>10 · Exceptional</span></div></div></div>)}</div>
      <label className="field note-field"><span>JUDGE NOTES <small>OPTIONAL</small></span><textarea rows="3" maxLength="1000" value={note} onChange={(e) => setNote(e.target.value)} placeholder="What stood out? What could be improved?" /></label>
      {message && <p className={message.includes('saved') ? 'form-success' : 'form-error'}>{message}</p>}
      <div className="form-footer"><p>{existingScore ? 'Your existing evaluation will be updated.' : 'Your score will be included in the team average.'}</p><button className="button button-primary" type="submit" disabled={busy || judgingClosed}>{busy ? 'Saving…' : 'Save evaluation'} <span>↗</span></button></div>
      </form><aside className="score-preview"><span className="section-kicker">LIVE SCORE PREVIEW</span><div className="score-ring"><strong>{preview.toFixed(1)}</strong><small>/ 100</small></div><p>Weighted composite score</p><div className="weight-breakdown">{RUBRIC.map((item) => <div key={item.key}><span>{item.label}</span><strong>{item.weight}%</strong></div>)}</div><div className="judge-total-note"><strong>{data.scores.length}</strong><span>evaluations submitted<br />across all projects</span></div><Link to="/leaderboard" className="text-link">See live leaderboard ↗</Link></aside></div>}
  </div>;
}
