# HackHarbor — HackOps Live (v2.0)

A full-stack hackathon event portal and operations MVP based on the HackHarbor brief and the Attempt #1 evaluation report. The project keeps the original responsive neon-hacker visual design and adds a server-authoritative API, persistent SQLite database, role-based judge authentication, team access tokens, deadline enforcement, error handling and automated tests.

## What changed after the evaluation report

The first attempt received **70/100 (Grade B)**. Its strongest area was Code Quality (90%); the report identified Security (50%), Innovation (40%), System Design (60%), missing automated tests, weak edge-case handling, and LocalStorage-only persistence as the main gaps.

| Evaluation feedback | Update in v2 |
|---|---|
| Hardcoded browser-side judge passcode | Removed. Judge email/password are configured in `.env`; multiple judge accounts can be configured as a JSON array. Passwords are bcrypt-hashed and verified by the API. |
| No server-side score validation | Express API checks JWT judge identity, score range, project existence and judging deadline. |
| LocalStorage-only data | SQLite tables persist teams, members, projects, judges, scores and invitation/access tokens. |
| No automated tests | Vitest + Supertest suites cover score weights, leaderboard sorting, auth gates, validation, access tokens and deadlines. |
| Weak error handling | Zod request validation, structured API errors, request IDs, explicit client messages and a React Error Boundary. |
| Weak deadline enforcement | Registration, submission and judging cutoffs are enforced on the server, not only hidden in the UI. |
| Project editing not access controlled | Random, expiring team access tokens bind project submission/update permission to one team. Invite tokens are hashed and expire. |

## Features

- Static HTML/CSS landing page at `static-phase/index.html` for Modules 1–2.
- React SPA with Discover, Register, Submit idea, Judges and Leaderboard routes.
- Five tracks: Fintech, EdTech, Healthcare, Web3 and Open Innovation.
- Team rosters of up to four members, duplicate-email validation and private invite URLs.
- Project details: title, tagline, GitHub repository, live demo, YouTube demo and technology tags.
- Four judging dimensions: Innovation 30%, Technical Complexity 30%, UI/UX 20%, Presentation 20%.
- Server-calculated weighted scores, an aggregate leaderboard and a judge-consensus monitor (standard deviation / outlier signal) that flags large scoring gaps for human review without altering the published weighted average.
- Leaderboard refreshes every five seconds across browsers connected to the same API/database.
- Dark/light mode using CSS custom properties and responsive layout.
- Event seed data: 12 teams, 8 submitted projects and sample judge scores.

## Requirements

- Node.js 20.19+ (Node 22 LTS recommended)
- npm

## First-time setup

1. Extract the ZIP and open the `hackharbor` folder in VS Code.
2. Install dependencies:

   ```bash
   npm install
   ```

3. Copy `.env.example` to `.env`.
4. Replace the `CHANGE_ME` placeholders. The judge password must be at least 12 characters and the JWT secret at least 32 characters. Generate a strong JWT secret with:

   ```bash
   node -e "console.log(require('node:crypto').randomBytes(48).toString('hex'))"
   ```

   Set your own long, unique `JUDGE_PASSWORD`. Do not commit `.env` or share judge credentials.

5. Start frontend and backend together:

   ```bash
   npm run dev
   ```

6. Open the Vite URL shown in the terminal (normally `http://localhost:5173`). The API runs on `http://localhost:4000` and Vite proxies `/api` requests to it.

The server creates `server/data/hackharbor.sqlite` on first run and inserts sample data. Database files are excluded from Git.

## Judge portal

Open **Judges** and sign in using the configured judge email/password. Set `JUDGE_EMAIL` and `JUDGE_PASSWORD` for a single Dr. Mehta account, or set `JUDGE_ACCOUNTS_JSON` to an array of judge objects (`id`, `name`, `title`, `email`, `password`) to activate multiple judge identities. Credentials are never embedded in the React bundle. A successful login receives a signed JWT that expires after four hours. The server rechecks that the judge account is active for each protected request.

## Team access and invitation flow

1. Register a team. The API validates the track, roster size, name and email uniqueness.
2. The server returns a private team access token and a separate invitation token. The browser keeps the team token in `sessionStorage`.
3. Share the invite URL with teammates. The token expires after 30 days; the API checks it and enforces the four-member limit before issuing each teammate a team access token.
4. Only a browser holding a valid team access token for that team can create/update its project submission.

The invitation URL grants the ability to join the team, so share it only with intended teammates. Do not post it publicly.

## Deadlines

Configure these values in `.env` using ISO timestamps with a timezone offset:

- `REGISTRATION_DEADLINE`
- `SUBMISSION_DEADLINE`
- `JUDGING_DEADLINE`

The UI displays a locked state after each deadline, and the API independently rejects late requests with HTTP `423 Locked`. For a practice event, move the deadlines to future timestamps before running the demo. Leave a value empty only when you intentionally want that phase to remain open.

## Tests and production build

Run the automated suites:

```bash
npm test
```

Create a production frontend bundle:

```bash
npm run build
```

Run the API and serve the built frontend from Express:

```bash
npm start
```

Or run both development servers with hot reload:

```bash
npm run dev
```

Run both tests and the frontend build together:

```bash
npm run check
```

## Main project structure

```text
hackharbor/
├── server/
│   ├── app.js                 # Express API, auth and route guards
│   ├── db.js                  # SQLite schema and starter data
│   ├── index.js               # Server bootstrap and static hosting
│   ├── rules.js               # Server-side scoring, deadlines, ranking
│   ├── validation.js          # Zod request schemas
│   ├── app.test.js            # API integration/security tests
│   └── rules.test.js          # Backend rule tests
├── src/
│   ├── components/            # Layout and React Error Boundary
│   ├── context/               # Shared application state and API actions
│   ├── data/                  # Event config and sample data
│   ├── pages/                 # Landing, register, submit, judge, leaderboard
│   └── utils/                 # API client and scoring tests
├── static-phase/              # Standalone HTML/CSS version
├── .env.example
├── package.json
└── vite.config.js
```


## API overview

All API responses are JSON. The React development server proxies `/api` to port `4000`.

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| `GET` | `/api/health` | Public | Health check |
| `GET` | `/api/bootstrap` | Public | Event data, roster counts, scores and deadlines |
| `POST` | `/api/teams` | Public | Validate and create a team; returns one private invite token and one team access token |
| `POST` | `/api/teams/:teamId/join` | Invite token | Add a teammate and issue that teammate a team access token |
| `POST` | `/api/projects` | `X-Team-Token` header | Create or update the matching team's project |
| `POST` | `/api/auth/judge` | Public, rate-limited | Verify judge credentials and issue a JWT |
| `GET` | `/api/auth/me` | Judge JWT | Validate the active judge session |
| `POST` | `/api/scores` | Judge JWT | Save the authenticated judge's scorecard |
| `GET` | `/api/leaderboard` | Public | Server-calculated ranking and judge-consensus metrics |

The leaderboard screen polls the bootstrap endpoint every five seconds so separate browsers see server-side changes without relying on browser storage events.

## Security and deployment notes

This is a substantially stronger academic MVP, not a fully audited production service. Before a public event, deploy behind HTTPS, set a unique production JWT secret and judge password, back up the SQLite database, configure trusted CORS origins, add email delivery/verification, monitor rate limits, and consider PostgreSQL for high-concurrency workloads. Team access tokens are scoped to a single team and expire after 30 days; judge sessions expire after four hours. Browser-held tokens remain exposed to a successful same-origin XSS attack, so keep dependencies updated and review any future HTML rendering carefully.

Email invitations currently open the user's email application using a `mailto:` link; the app does not send email automatically. The initial judge account is one administrator-configured judge; the sample scores from other judge profiles remain seeded leaderboard data.

## Original static phase

Open `static-phase/index.html` directly in a browser to present the HTML/CSS-only landing page. It has its own stylesheet and does not require the API or npm packages.
