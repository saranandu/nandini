import { RUBRIC } from '../data/eventConfig';

export function scoreOutOf100(score) {
  if (!score) return 0;
  return RUBRIC.reduce((total, criterion) => {
    return total + (Number(score[criterion.key]) || 0) * criterion.weight;
  }, 0) / 10;
}

export function getLeaderboard(data, track = 'All tracks') {
  const rows = data.teams
    .filter((team) => track === 'All tracks' || team.track === track)
    .map((team) => {
      const teamProjects = data.projects.filter((project) => project.teamId === team.id);
      const teamScores = data.scores.filter((score) => teamProjects.some((project) => project.id === score.projectId));
      const average = teamScores.length
        ? teamScores.reduce((sum, score) => sum + scoreOutOf100(score), 0) / teamScores.length
        : 0;
      return {
        ...team,
        project: teamProjects[0] || null,
        score: average,
        scoreCount: teamScores.length,
        scored: teamScores.length > 0,
      };
    });

  return rows.sort((a, b) => {
    if (a.scored !== b.scored) return a.scored ? -1 : 1;
    if (b.score !== a.score) return b.score - a.score;
    return a.name.localeCompare(b.name);
  });
}
