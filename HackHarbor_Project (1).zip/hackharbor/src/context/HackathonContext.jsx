import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { createSeedData } from '../data/seed';

const STORAGE_KEY = 'hackharbor-v1';
const HackathonContext = createContext(null);

function readStoredData() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return createSeedData();
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed.teams) || !Array.isArray(parsed.projects) || !Array.isArray(parsed.scores)) {
      return createSeedData();
    }
    return parsed;
  } catch {
    return createSeedData();
  }
}

export function HackathonProvider({ children }) {
  const [data, setData] = useState(readStoredData);
  const [isJudge, setIsJudge] = useState(false);
  const [theme, setTheme] = useState(() => localStorage.getItem('hackharbor-theme') || 'dark');

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }, [data]);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    localStorage.setItem('hackharbor-theme', theme);
  }, [theme]);

  useEffect(() => {
    const syncAcrossTabs = (event) => {
      if (event.key !== STORAGE_KEY || !event.newValue) return;
      try {
        const next = JSON.parse(event.newValue);
        if (Array.isArray(next.teams) && Array.isArray(next.projects) && Array.isArray(next.scores)) setData(next);
      } catch {
        // Ignore malformed updates from another browser tab.
      }
    };
    window.addEventListener('storage', syncAcrossTabs);
    return () => window.removeEventListener('storage', syncAcrossTabs);
  }, []);

  const addTeam = useCallback((team) => {
    const saved = { ...team, id: `team-${crypto.randomUUID()}`, createdAt: new Date().toISOString() };
    setData((current) => ({ ...current, teams: [...current.teams, saved] }));
    return saved;
  }, []);

  const addTeamMember = useCallback((teamId, member) => {
    setData((current) => ({
      ...current,
      teams: current.teams.map((team) => team.id === teamId && team.members.length < 4
        ? { ...team, members: [...team.members, { ...member, role: 'Member' }] }
        : team),
    }));
  }, []);

  const addProject = useCallback((project) => {
    const saved = { ...project, id: `project-${crypto.randomUUID()}`, createdAt: new Date().toISOString() };
    setData((current) => ({ ...current, projects: [...current.projects.filter((item) => item.teamId !== project.teamId), saved] }));
    return saved;
  }, []);

  const saveScore = useCallback((score) => {
    const saved = { ...score, id: score.id || `score-${crypto.randomUUID()}`, updatedAt: new Date().toISOString() };
    setData((current) => ({
      ...current,
      scores: [...current.scores.filter((item) => !(item.projectId === score.projectId && item.judgeId === score.judgeId)), saved],
    }));
  }, []);

  const resetDemo = useCallback(() => setData(createSeedData()), []);
  const loginJudge = useCallback(() => setIsJudge(true), []);
  const logoutJudge = useCallback(() => setIsJudge(false), []);
  const toggleTheme = useCallback(() => setTheme((current) => current === 'dark' ? 'light' : 'dark'), []);

  const value = useMemo(() => ({
    data, addTeam, addTeamMember, addProject, saveScore, isJudge, loginJudge, logoutJudge,
    theme, toggleTheme, resetDemo,
  }), [data, addTeam, addTeamMember, addProject, saveScore, isJudge, loginJudge, logoutJudge, theme, toggleTheme, resetDemo]);

  return <HackathonContext.Provider value={value}>{children}</HackathonContext.Provider>;
}

export function useHackathon() {
  const context = useContext(HackathonContext);
  if (!context) throw new Error('useHackathon must be used inside HackathonProvider');
  return context;
}
