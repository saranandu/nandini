import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { useHackathon } from '../context/HackathonContext';

const isValidUrl = (value) => {
  if (!value.trim()) return true;
  try { const parsed = new URL(value); return ['http:', 'https:'].includes(parsed.protocol); }
  catch { return false; }
};
const isGithubUrl = (value) => !value.trim() || /^https?:\/\/(www\.)?github\.com\/[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+\/?$/i.test(value.trim());

export default function Submit() {
  const { data, addProject } = useHackathon();
  const [teamId, setTeamId] = useState(data.teams[0]?.id || '');
  const [title, setTitle] = useState('');
  const [tagline, setTagline] = useState('');
  const [github, setGithub] = useState('');
  const [demo, setDemo] = useState('');
  const [video, setVideo] = useState('');
  const [stack, setStack] = useState('');
  const [error, setError] = useState('');
  const [saved, setSaved] = useState(null);
  const selectedTeam = useMemo(() => data.teams.find((team) => team.id === teamId), [data.teams, teamId]);
  const existingProject = data.projects.find((project) => project.teamId === teamId);

  const handleSubmit = (event) => {
    event.preventDefault(); setError('');
    if (!teamId || !title.trim() || !tagline.trim() || !github.trim()) return setError('Choose your team and complete the title, tagline and GitHub repository.');
    if (!isGithubUrl(github)) return setError('Enter a valid GitHub repository URL, such as https://github.com/owner/repository.');
    if (!isValidUrl(demo) || !isValidUrl(video)) return setError('Demo and video links must be valid http or https URLs.');
    const project = addProject({ teamId, title: title.trim(), tagline: tagline.trim(), github: github.trim(), demo: demo.trim(), video: video.trim(), stack: stack.split(',').map((item) => item.trim()).filter(Boolean).slice(0, 8) });
    setSaved(project);
  };

  if (!data.teams.length) return <div className="page-wrap empty-state"><span className="section-kicker">02 / PROJECT SUBMISSION</span><h1>First, get your<br /><span className="muted-heading">team on the list.</span></h1><p>Project submissions are connected to a registered team.</p><Link className="button button-primary" to="/register">Register a team <span>↗</span></Link></div>;

  return (
    <div className="page-wrap form-page">
      <div className="page-heading"><span className="section-kicker">02 / PROJECT SUBMISSION</span><h1>Put your idea<br /><span className="muted-heading">out into the world.</span></h1><p>Give the judges a clear first look. You can update your team's submission by saving this form again.</p></div>
      {saved ? <section className="success-card"><div className="success-icon">↗</div><span className="section-kicker">SUBMISSION RECEIVED</span><h2>{saved.title}<br /><span className="muted-heading">is in the harbor.</span></h2><p><strong>{selectedTeam?.name || 'Your team'}</strong> · {selectedTeam?.track || 'Track'}</p><div className="submission-links"><a href={saved.github} target="_blank" rel="noreferrer">GitHub repository ↗</a>{saved.demo && <a href={saved.demo} target="_blank" rel="noreferrer">Live demo ↗</a>}</div><div className="success-actions"><Link to="/leaderboard" className="button button-primary">View leaderboard <span>↗</span></Link><button className="button button-ghost" onClick={() => setSaved(null)}>Edit submission</button></div></section> : (
        <form className="form-card" onSubmit={handleSubmit}>
          <div className="form-card-title"><div><span className="section-kicker">THE BIG IDEA</span><h2>Project details</h2></div><span className="form-step mono">HACKVERSE / 2026</span></div>
          {existingProject && <div className="notice-banner">This team already has a submission: <strong>{existingProject.title}</strong>. Saving this form will update it.</div>}
          <div className="field-grid"><label className="field full-field"><span>SUBMITTING TEAM <b>*</b></span><select value={teamId} onChange={(e) => setTeamId(e.target.value)}>{data.teams.map((team) => <option value={team.id} key={team.id}>{team.name} — {team.track}</option>)}</select></label><label className="field"><span>PROJECT TITLE <b>*</b></span><input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. CardioScan" maxLength={48} required /></label><label className="field"><span>TAGLINE <b>*</b></span><input value={tagline} onChange={(e) => setTagline(e.target.value)} placeholder="Your idea in one sentence" maxLength={100} required /></label><label className="field full-field"><span>GITHUB REPOSITORY <b>*</b></span><input type="url" value={github} onChange={(e) => setGithub(e.target.value)} placeholder="https://github.com/your-team/your-project" required /></label><label className="field"><span>LIVE DEMO URL</span><input type="url" value={demo} onChange={(e) => setDemo(e.target.value)} placeholder="https://your-demo.com" /></label><label className="field"><span>YOUTUBE VIDEO DEMO</span><input type="url" value={video} onChange={(e) => setVideo(e.target.value)} placeholder="https://youtube.com/watch?v=..." /></label><label className="field full-field"><span>TECH STACK <small>COMMA-SEPARATED</small></span><input value={stack} onChange={(e) => setStack(e.target.value)} placeholder="React, Python, TensorFlow, Firebase" /></label></div>
          {error && <p className="form-error">{error}</p>}
          <div className="form-footer"><p>Links should be accessible to the judging team.</p><button type="submit" className="button button-primary">Submit project <span>↗</span></button></div>
        </form>
      )}
      <div className="form-aside"><span className="aside-star">✳</span><p>Tip: make your README easy to follow and include a short explanation of the problem, solution and setup.</p><Link to="/judge">See judging rubric <span>↗</span></Link></div>
    </div>
  );
}
