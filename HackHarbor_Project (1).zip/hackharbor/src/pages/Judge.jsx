import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { JUDGES, RUBRIC, EVENT_CONFIG } from '../data/eventConfig';
import { useHackathon } from '../context/HackathonContext';
import { scoreOutOf100 } from '../utils/scoring';

export default function Judge() {
  const { data, isJudge, loginJudge, saveScore } = useHackathon();
  const [passcode, setPasscode] = useState('');
  const [judgeId, setJudgeId] = useState(JUDGES[0].id);
  const [projectId, setProjectId] = useState(data.projects[0]?.id || '');
  const [scores, setScores] = useState({ innovation: 8, complexity: 8, uiux: 8, presentation: 8 });
  const [note, setNote] = useState('');
  const [message, setMessage] = useState('');
  const project = useMemo(() => data.projects.find((item) => item.id === projectId), [data.projects, projectId]);
  const team = useMemo(() => data.teams.find((item) => item.id === project?.teamId), [data.teams, project]);
  const existingScore = data.scores.find((item) => item.projectId === projectId && item.judgeId === judgeId);
  const preview = scoreOutOf100(scores);

  const selectProject = (id) => {
    setProjectId(id);
    const existing = data.scores.find((item) => item.projectId === id && item.judgeId === judgeId);
    if (existing) { setScores({ innovation: existing.innovation, complexity: existing.complexity, uiux: existing.uiux, presentation: existing.presentation }); setNote(existing.note || ''); }
    else { setScores({ innovation: 8, complexity: 8, uiux: 8, presentation: 8 }); setNote(''); }
    setMessage('');
  };
  const selectJudge = (id) => {
    setJudgeId(id);
    const existing = data.scores.find((item) => item.projectId === projectId && item.judgeId === id);
    if (existing) { setScores({ innovation: existing.innovation, complexity: existing.complexity, uiux: existing.uiux, presentation: existing.presentation }); setNote(existing.note || ''); }
    else { setScores({ innovation: 8, complexity: 8, uiux: 8, presentation: 8 }); setNote(''); }
    setMessage('');
  };
  const handleLogin = (event) => {
    event.preventDefault();
    if (passcode === EVENT_CONFIG.judgePasscode) { loginJudge(); setMessage('Judge access granted.'); }
    else setMessage('That passcode does not match. Check the demo credentials in eventConfig.js.');
  };
  const handleSave = (event) => {
    event.preventDefault();
    if (!project) return;
    saveScore({ projectId, judgeId, ...scores, note: note.trim() });
    setMessage(`Evaluation saved for ${project.title}. The leaderboard has been updated.`);
  };

  if (!isJudge) return <div className="page-wrap judge-login-wrap"><div className="judge-login-card"><div className="judge-lock">⌑</div><span className="section-kicker">RESTRICTED AREA / JUDGES ONLY</span><h1>Welcome to the<br /><span className="muted-heading">judging console.</span></h1><p>Enter the demo judge passcode to access project evaluations.</p><form onSubmit={handleLogin}><label className="field"><span>JUDGE PASSCODE</span><input type="password" value={passcode} onChange={(e) => setPasscode(e.target.value)} placeholder="Enter passcode" required /></label>{message && <p className={message.startsWith('Judge access') ? 'form-success' : 'form-error'}>{message}</p>}<button type="submit" className="button button-primary button-full">Unlock console <span>↗</span></button></form><div className="demo-credentials"><span>DEMO PASSCODE</span><code>HARBOR2026</code><small>Demo-only access control; not production authentication.</small></div></div></div>;

  return <div className="page-wrap judge-page"><div className="page-heading compact-heading"><span className="section-kicker">03 / EVALUATION CONSOLE</span><h1>Judge the work.<br /><span className="muted-heading">Reward the thinking.</span></h1><p>Score each project on four weighted dimensions. Your evaluation contributes to the live leaderboard.</p></div>
    {!data.projects.length ? <div className="empty-state"><h2>No projects yet.</h2><p>Project submissions will appear here when teams submit their work.</p><Link to="/submit" className="text-link">Go to submissions ↗</Link></div> : <div className="judge-layout"><form className="form-card judge-form" onSubmit={handleSave}><div className="form-card-title"><div><span className="section-kicker">EVALUATION SHEET</span><h2>Project scorecard</h2></div><span className="judge-status"><i /> ACTIVE</span></div><div className="field-grid"><label className="field"><span>JUDGE PROFILE</span><select value={judgeId} onChange={(e) => selectJudge(e.target.value)}>{JUDGES.map((judge) => <option value={judge.id} key={judge.id}>{judge.name} · {judge.title}</option>)}</select></label><label className="field"><span>PROJECT TO EVALUATE</span><select value={projectId} onChange={(e) => selectProject(e.target.value)}>{data.projects.map((item) => <option value={item.id} key={item.id}>{item.title}</option>)}</select></label></div>{project && <div className="judge-project-summary"><div><span className="section-kicker">{team?.track || 'TRACK'}</span><h3>{project.title}</h3><p>{project.tagline}</p></div><div className="judge-project-links"><a href={project.github} target="_blank" rel="noreferrer">GitHub ↗</a>{project.demo && <a href={project.demo} target="_blank" rel="noreferrer">Live demo ↗</a>}{project.video && <a href={project.video} target="_blank" rel="noreferrer">Video ↗</a>}</div></div>}
      <div className="rubric-heading"><div><span className="section-kicker">THE RUBRIC</span><h3>Evaluation criteria</h3></div><span className="mono">SCORE EACH 1–10</span></div>
      <div className="rubric-list">{RUBRIC.map((item) => <div className="rubric-item" key={item.key}><div className="rubric-top"><div><strong>{item.label}</strong><p>{item.hint}</p></div><div className="rubric-score"><strong>{scores[item.key]}</strong><small>/ 10</small></div></div><div className="rubric-weight"><span>{item.weight}% WEIGHT</span><input type="range" min="1" max="10" step="1" value={scores[item.key]} onChange={(e) => setScores((current) => ({ ...current, [item.key]: Number(e.target.value) }))} aria-label={`${item.label} score`} /><div className="range-labels"><span>1 · Needs work</span><span>10 · Exceptional</span></div></div></div>)}</div>
      <label className="field note-field"><span>JUDGE NOTES <small>OPTIONAL</small></span><textarea rows="3" value={note} onChange={(e) => setNote(e.target.value)} placeholder="What stood out? What could be improved?" /></label>
      {message && <p className={message.includes('saved') ? 'form-success' : 'form-error'}>{message}</p>}
      <div className="form-footer"><p>{existingScore ? 'You have already scored this project. Saving will update your evaluation.' : 'Your score will be included in the team average.'}</p><button className="button button-primary" type="submit">Save evaluation <span>↗</span></button></div>
      </form><aside className="score-preview"><span className="section-kicker">LIVE SCORE PREVIEW</span><div className="score-ring"><strong>{preview.toFixed(1)}</strong><small>/ 100</small></div><p>Weighted composite score</p><div className="weight-breakdown">{RUBRIC.map((item) => <div key={item.key}><span>{item.label}</span><strong>{item.weight}%</strong></div>)}</div><div className="judge-total-note"><strong>{data.scores.length}</strong><span>evaluations submitted<br />across all projects</span></div><Link to="/leaderboard" className="text-link">See live leaderboard ↗</Link></aside></div>}
  </div>;
}
